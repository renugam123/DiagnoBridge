import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/use-auth';
import NavBar from '@/components/NavBar';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertCircle, ArrowLeft, Check } from 'lucide-react';

export default function SaveEncounter() {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    navigate('/role-selection');
    return null;
  }

  return (
    <div className="min-h-screen bg-background dark:bg-slate-900">
      <NavBar />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Button
          onClick={() => navigate('/dashboard')}
          variant="ghost"
          className="mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </Button>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2">
            <Card>
              <CardHeader>
                <CardTitle>Save Encounter</CardTitle>
                <CardDescription>
                  Review and confirm the diagnosis mapping before saving
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-6 p-6 bg-blue-50 dark:bg-blue-900/20 rounded-lg border border-blue-200 dark:border-blue-800">
                  <div className="flex items-start gap-3">
                    <AlertCircle className="w-5 h-5 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
                    <div>
                      <h3 className="font-semibold text-blue-900 dark:text-blue-100">
                        Feature Coming Soon
                      </h3>
                      <p className="text-sm text-blue-800 dark:text-blue-200 mt-2">
                        The Save Encounter feature is being developed. This page will allow you to:
                      </p>
                      <ul className="text-sm text-blue-800 dark:text-blue-200 mt-3 ml-5 list-disc space-y-1">
                        <li>Review diagnosis mapping details</li>
                        <li>Confirm codes and confidence scores</li>
                        <li>Add clinical notes and observations</li>
                        <li>Save the encounter to patient records</li>
                        <li>Generate encounter documentation</li>
                      </ul>
                    </div>
                  </div>
                </div>

                <div className="mt-6">
                  <p className="text-sm text-muted-foreground mb-4">
                    Continue exploring the system:
                  </p>
                  <Button
                    onClick={() => navigate('/dashboard')}
                    className="w-full btn-primary py-6"
                  >
                    <Check className="w-4 h-4 mr-2" />
                    Return to Dashboard
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div>
            <Card>
              <CardHeader>
                <CardTitle className="text-lg">Process Steps</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-health-teal text-white flex items-center justify-center text-xs font-bold flex-shrink-0">
                    ✓
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">Doctor Login</p>
                    <p className="text-xs text-muted-foreground">Completed</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-health-teal text-white flex items-center justify-center text-xs font-bold flex-shrink-0">
                    ✓
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">Diagnosis Search</p>
                    <p className="text-xs text-muted-foreground">Completed</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-health-blue text-white flex items-center justify-center text-xs font-bold flex-shrink-0">
                    3
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">Save Encounter</p>
                    <p className="text-xs text-muted-foreground">In progress</p>
                  </div>
                </div>
                <div className="flex items-start gap-3">
                  <div className="w-6 h-6 rounded-full bg-muted text-muted-foreground flex items-center justify-center text-xs font-bold flex-shrink-0">
                    4
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-muted-foreground">View History</p>
                    <p className="text-xs text-muted-foreground">Coming soon</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </main>
    </div>
  );
}
