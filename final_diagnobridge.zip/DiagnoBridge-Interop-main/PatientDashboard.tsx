import { useNavigate } from 'react-router-dom';
import { useAuth, Patient } from '@/hooks/use-auth';
import NavBar from '@/components/NavBar';
import { Button } from '@/components/ui/button';
import { Plus } from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Calendar,
  FileText,
  Heart,
  User,
  AlertCircle,
  Download,
  Clock,
} from 'lucide-react';
import { useEffect } from 'react';

export default function PatientDashboard() {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/role-selection');
      return;
    }
  }, [isAuthenticated, navigate]);

  const patient = user as Patient;

  // Mock medical records
  const medicalRecords = [
    {
      id: '1',
      date: '2024-01-15',
      doctor: 'Dr. Rajesh Kumar',
      diagnosis: 'Hypertension',
      status: 'Active Treatment',
    },
    {
      id: '2',
      date: '2024-01-10',
      doctor: 'Dr. Priya Singh',
      diagnosis: 'Diabetes Mellitus',
      status: 'Under Management',
    },
    {
      id: '3',
      date: '2024-01-05',
      doctor: 'Dr. Vikram Patel',
      diagnosis: 'Anxiety Disorder',
      status: 'In Progress',
    },
  ];

  const appointmentHistory = [
    {
      id: '1',
      date: '2024-01-20',
      time: '10:00 AM',
      doctor: 'Dr. Rajesh Kumar',
      status: 'Completed',
    },
    {
      id: '2',
      date: '2024-01-25',
      time: '2:00 PM',
      doctor: 'Dr. Priya Singh',
      status: 'Upcoming',
    },
  ];

  return (
    <div className="min-h-screen bg-background dark:bg-slate-900">
      <NavBar />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="mb-8 flex items-center justify-between">
          <div>
            <h2 className="text-3xl font-bold text-foreground mb-2">
              My Health Dashboard
            </h2>
            <p className="text-muted-foreground">
              View your medical records, appointments, and health information
            </p>
          </div>
          <Button
            onClick={() => navigate('/patient-diagnosis')}
            className="btn-primary whitespace-nowrap"
          >
            <Plus className="w-4 h-4 mr-2" />
            Submit Diagnosis
          </Button>
        </div>

        {/* Patient Information Card */}
        <Card className="mb-8 bg-gradient-to-br from-health-teal/5 to-health-blue/5 dark:from-slate-800 dark:to-slate-800 border-health-teal/30">
          <CardHeader className="pb-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-full bg-health-teal/20 flex items-center justify-center">
                  <User className="w-6 h-6 text-health-teal" />
                </div>
                <div>
                  <CardTitle className="text-xl">My Profile</CardTitle>
                  <CardDescription>Personal health information</CardDescription>
                </div>
              </div>
              <Badge className="bg-health-green/20 text-health-green border-0">
                Active
              </Badge>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">
                  Full Name
                </Label>
                <p className="font-semibold text-foreground">{patient.name}</p>
              </div>
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">
                  Email Address
                </Label>
                <p className="font-mono font-semibold text-foreground text-sm">
                  {patient.email}
                </p>
              </div>
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">
                  Phone Number
                </Label>
                <p className="font-semibold text-foreground">
                  {patient.phoneNumber}
                </p>
              </div>
              <div className="space-y-1">
                <Label className="text-xs text-muted-foreground">
                  Date of Birth
                </Label>
                <p className="font-semibold text-foreground">
                  {new Date(patient.dateOfBirth).toLocaleDateString('en-IN', {
                    year: 'numeric',
                    month: 'long',
                    day: 'numeric',
                  })}
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Stats */}
        <div className="grid md:grid-cols-4 gap-4 mb-8">
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <Heart className="w-8 h-8 text-health-teal mx-auto mb-2" />
                <p className="text-3xl font-bold text-foreground">{medicalRecords.length}</p>
                <p className="text-sm text-muted-foreground">Active Conditions</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <Calendar className="w-8 h-8 text-health-blue mx-auto mb-2" />
                <p className="text-3xl font-bold text-foreground">
                  {appointmentHistory.filter((a) => a.status === 'Upcoming').length}
                </p>
                <p className="text-sm text-muted-foreground">Upcoming Appointments</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <FileText className="w-8 h-8 text-health-green mx-auto mb-2" />
                <p className="text-3xl font-bold text-foreground">{medicalRecords.length}</p>
                <p className="text-sm text-muted-foreground">Medical Records</p>
              </div>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="pt-6">
              <div className="text-center">
                <Clock className="w-8 h-8 text-amber-600 mx-auto mb-2" />
                <p className="text-3xl font-bold text-foreground">
                  {appointmentHistory.filter((a) => a.status === 'Completed').length}
                </p>
                <p className="text-sm text-muted-foreground">Past Visits</p>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Medical Records */}
        <Card className="mb-8">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div>
                <CardTitle>Medical Records</CardTitle>
                <CardDescription>Your active diagnoses and treatments</CardDescription>
              </div>
              <Button variant="outline" size="sm">
                <Download className="w-4 h-4 mr-2" />
                Export
              </Button>
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {medicalRecords.map((record) => (
                <div
                  key={record.id}
                  className="flex items-center justify-between p-4 bg-muted dark:bg-slate-800 rounded-lg border border-border dark:border-slate-700"
                >
                  <div className="flex-1">
                    <h4 className="font-semibold text-foreground mb-1">
                      {record.diagnosis}
                    </h4>
                    <p className="text-sm text-muted-foreground">
                      Dr. {record.doctor} • {new Date(record.date).toLocaleDateString()}
                    </p>
                  </div>
                  <Badge variant="secondary">{record.status}</Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Appointment History */}
        <Card>
          <CardHeader>
            <CardTitle>Appointment History</CardTitle>
            <CardDescription>Your recent and upcoming appointments</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {appointmentHistory.map((appointment) => (
                <div
                  key={appointment.id}
                  className="flex items-center justify-between p-4 bg-muted dark:bg-slate-800 rounded-lg border border-border dark:border-slate-700"
                >
                  <div className="flex items-center gap-4">
                    <Calendar className="w-5 h-5 text-health-teal" />
                    <div>
                      <h4 className="font-semibold text-foreground">
                        Dr. {appointment.doctor}
                      </h4>
                      <p className="text-sm text-muted-foreground">
                        {new Date(appointment.date).toLocaleDateString()} at{' '}
                        {appointment.time}
                      </p>
                    </div>
                  </div>
                  <Badge
                    className={
                      appointment.status === 'Completed'
                        ? 'bg-health-green/20 text-health-green border-0'
                        : 'bg-health-blue/20 text-health-blue border-0'
                    }
                  >
                    {appointment.status}
                  </Badge>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        {/* Important Notice */}
        <Card className="mt-8 border-amber-200 dark:border-amber-800 bg-amber-50 dark:bg-amber-900/20">
          <CardContent className="pt-6">
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-amber-600 mt-0.5 flex-shrink-0" />
              <div>
                <h4 className="font-semibold text-amber-900 dark:text-amber-100 mb-1">
                  Important Notice
                </h4>
                <p className="text-sm text-amber-800 dark:text-amber-200">
                  Please consult with your doctor before making any changes to your
                  treatment. All medical information shown here is confidential and
                  protected under healthcare privacy laws.
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}

// Import Label component
function Label({ className, children }: { className?: string; children: React.ReactNode }) {
  return <label className={`text-xs font-medium text-muted-foreground ${className || ''}`}>{children}</label>;
}
