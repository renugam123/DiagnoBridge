import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth, Patient } from '@/hooks/use-auth';
import { medicalSystems, searchDiagnosis } from '@/lib/mock-data';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { AlertCircle, CheckCircle2, Loader2, Search, Stethoscope } from 'lucide-react';

type SubmissionStep = 'system-selection' | 'diagnosis-entry' | 'confirmation' | 'success';

export default function PatientDiagnosisPortal() {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();

  const [step, setStep] = useState<SubmissionStep>('system-selection');
  const [selectedSystem, setSelectedSystem] = useState('');
  const [diagnosisTerm, setDiagnosisTerm] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [diagnosisResult, setDiagnosisResult] = useState<any>(null);

  if (!isAuthenticated) {
    navigate('/role-selection');
    return null;
  }

  const patient = user as Patient;

  const handleSystemSelect = () => {
    if (!selectedSystem) {
      setError('Please select a medical system');
      return;
    }
    setError('');
    setStep('diagnosis-entry');
  };

  const handleDiagnosisSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!diagnosisTerm.trim()) {
      setError('Please enter your diagnosis or symptoms');
      return;
    }

    setLoading(true);
    // Simulate search
    setTimeout(() => {
      const result = searchDiagnosis(diagnosisTerm);
      if (result) {
        setDiagnosisResult(result);
        setStep('confirmation');
      } else {
        setError('Diagnosis not found. Please try different terminology.');
      }
      setLoading(false);
    }, 800);
  };

  const handleSubmitDiagnosis = () => {
    if (!diagnosisResult) return;
    
    // In a real system, this would:
    // 1. Save the diagnosis to database
    // 2. Trigger AI doctor allocation
    // 3. Create a doctor-patient assignment
    // 4. Notify the allocated doctor
    
    setStep('success');
    
    // Redirect to confirmation after delay
    setTimeout(() => {
      navigate('/patient-dashboard');
    }, 2000);
  };

  return (
    <div className="min-h-screen bg-background dark:bg-slate-900">
      {/* Header */}
      <div className="border-b border-border dark:border-slate-700 bg-card dark:bg-slate-800/50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-health-blue to-health-teal flex items-center justify-center shadow-md">
              <span className="text-white font-bold text-sm">DB</span>
            </div>
            <div>
              <h1 className="text-lg font-bold text-foreground">DiagnoBridge</h1>
              <p className="text-xs text-muted-foreground">Interop</p>
            </div>
          </div>
          <Button
            onClick={() => navigate('/patient-dashboard')}
            variant="ghost"
          >
            Back to Dashboard
          </Button>
        </div>
      </div>

      <main className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        {/* Welcome Card */}
        <Card className="mb-8 bg-gradient-to-br from-health-teal/5 to-health-blue/5 dark:from-slate-800 dark:to-slate-800 border-health-teal/30">
          <CardHeader>
            <CardTitle className="text-2xl">Submit Your Diagnosis</CardTitle>
            <CardDescription>
              Share your medical condition in any medical system. Our AI will assign a qualified doctor to your case and provide comprehensive diagnosis mapping.
            </CardDescription>
          </CardHeader>
        </Card>

        {/* Step 1: Medical System Selection */}
        {step === 'system-selection' && (
          <Card>
            <CardHeader>
              <CardTitle>Step 1: Choose Your Medical System</CardTitle>
              <CardDescription>
                Select the medical system in which you're familiar with your condition
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-3">
                {medicalSystems.map((system) => (
                  <button
                    key={system}
                    onClick={() => setSelectedSystem(system)}
                    className={`w-full p-4 rounded-lg border-2 transition-all text-left ${
                      selectedSystem === system
                        ? 'border-health-teal bg-health-teal/5 dark:bg-slate-700'
                        : 'border-border dark:border-slate-700 hover:border-health-teal/50'
                    }`}
                  >
                    <p className="font-semibold text-foreground">{system}</p>
                    <p className="text-xs text-muted-foreground mt-1">
                      Use terminology familiar from this medical system
                    </p>
                  </button>
                ))}
              </div>

              {error && (
                <div className="flex items-center gap-2 text-destructive text-sm bg-destructive/10 p-3 rounded-lg">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  {error}
                </div>
              )}

              <Button
                onClick={handleSystemSelect}
                className="w-full btn-primary py-6"
              >
                Continue to Diagnosis Entry
              </Button>
            </CardContent>
          </Card>
        )}

        {/* Step 2: Diagnosis Entry */}
        {step === 'diagnosis-entry' && (
          <Card>
            <CardHeader>
              <CardTitle>Step 2: Enter Your Diagnosis or Symptoms</CardTitle>
              <CardDescription>
                Type your condition as you would describe it in {selectedSystem}
              </CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="bg-blue-50 dark:bg-slate-700/50 border border-health-blue/30 rounded-lg p-4">
                <p className="text-sm text-muted-foreground">
                  Selected System: <span className="font-semibold text-foreground">{selectedSystem}</span>
                </p>
              </div>

              <form onSubmit={handleDiagnosisSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="diagnosis" className="label-text">
                    Diagnosis Term or Symptoms
                  </Label>
                  <div className="relative">
                    <Search className="absolute left-3 top-3.5 w-5 h-5 text-muted-foreground" />
                    <Input
                      id="diagnosis"
                      type="text"
                      placeholder={`e.g., Fever, Jvara, Madhumeha, Sirashoola...`}
                      value={diagnosisTerm}
                      onChange={(e) => {
                        setDiagnosisTerm(e.target.value);
                        setError('');
                      }}
                      className="pl-10"
                    />
                  </div>
                  <p className="text-xs text-muted-foreground">
                    Use medical terminology familiar to you
                  </p>
                </div>

                {error && (
                  <div className="flex items-center gap-2 text-destructive text-sm bg-destructive/10 p-3 rounded-lg">
                    <AlertCircle className="w-4 h-4 flex-shrink-0" />
                    {error}
                  </div>
                )}

                <div className="flex gap-3">
                  <Button
                    type="submit"
                    disabled={loading || !diagnosisTerm.trim()}
                    className="flex-1 btn-primary py-6"
                  >
                    {loading ? (
                      <>
                        <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                        Searching...
                      </>
                    ) : (
                      <>
                        <Search className="w-4 h-4 mr-2" />
                        Search Diagnosis
                      </>
                    )}
                  </Button>
                  <Button
                    type="button"
                    onClick={() => setStep('system-selection')}
                    variant="outline"
                    className="px-6"
                  >
                    Back
                  </Button>
                </div>
              </form>
            </CardContent>
          </Card>
        )}

        {/* Step 3: Confirmation */}
        {step === 'confirmation' && diagnosisResult && (
          <div className="space-y-6">
            <Card className="border-health-green/50 bg-health-green/5">
              <CardHeader>
                <CardTitle className="flex items-center gap-2">
                  <CheckCircle2 className="w-6 h-6 text-health-green" />
                  Diagnosis Found
                </CardTitle>
                <CardDescription>
                  Please review the mapping before submission
                </CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                {/* Input Term */}
                <div className="p-4 bg-white dark:bg-slate-700 rounded-lg border border-border">
                  <Label className="text-xs text-muted-foreground">Your Input</Label>
                  <div className="flex items-center gap-2 mt-1">
                    <p className="text-lg font-bold text-foreground">
                      {diagnosisTerm}
                    </p>
                    <Badge className="ml-2">{selectedSystem}</Badge>
                  </div>
                </div>

                {/* NAMASTE Code */}
                <div className="p-4 bg-white dark:bg-slate-700 rounded-lg border border-border">
                  <Label className="text-xs text-muted-foreground">NAMASTE (AYUSH) Code</Label>
                  <p className="text-lg font-bold text-health-blue mt-1">
                    {diagnosisResult.namaste.code}
                  </p>
                  <p className="text-sm text-foreground">{diagnosisResult.namaste.name}</p>
                </div>

                {/* ICD-11 Codes */}
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="p-4 bg-white dark:bg-slate-700 rounded-lg border border-border">
                    <Label className="text-xs text-muted-foreground">ICD-11 TM2 Code</Label>
                    <p className="text-lg font-bold text-health-teal mt-1">
                      {diagnosisResult.icd11tm2.code}
                    </p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-xs text-foreground">
                        {diagnosisResult.icd11tm2.name}
                      </span>
                      <Badge className="bg-health-teal/20 text-health-teal border-0">
                        {Math.round(diagnosisResult.icd11tm2.confidence * 100)}%
                      </Badge>
                    </div>
                  </div>

                  <div className="p-4 bg-white dark:bg-slate-700 rounded-lg border border-border">
                    <Label className="text-xs text-muted-foreground">ICD-11 Biomedical</Label>
                    <p className="text-lg font-bold text-health-blue mt-1">
                      {diagnosisResult.icd11biomedical.code}
                    </p>
                    <div className="flex items-center justify-between mt-2">
                      <span className="text-xs text-foreground">
                        {diagnosisResult.icd11biomedical.name}
                      </span>
                      <Badge className="bg-health-blue/20 text-health-blue border-0">
                        {Math.round(diagnosisResult.icd11biomedical.confidence * 100)}%
                      </Badge>
                    </div>
                  </div>
                </div>

                {/* Patient Confirmation */}
                <div className="bg-amber-50 dark:bg-slate-700/50 border border-amber-200 dark:border-amber-800 rounded-lg p-4">
                  <p className="text-sm text-foreground font-semibold mb-2">
                    Diagnosis will be submitted as:
                  </p>
                  <div className="space-y-1 text-sm text-muted-foreground">
                    <p>Patient: <span className="font-semibold text-foreground">{patient.name}</span></p>
                    <p>ABHA ID: <span className="font-semibold text-foreground">{patient.abhaId || 'To be updated'}</span></p>
                    <p>A qualified doctor will be automatically assigned to your case</p>
                  </div>
                </div>

                {/* Action Buttons */}
                <div className="flex gap-3">
                  <Button
                    onClick={handleSubmitDiagnosis}
                    className="flex-1 btn-primary py-6"
                  >
                    <Stethoscope className="w-4 h-4 mr-2" />
                    Submit Diagnosis for Doctor Assignment
                  </Button>
                  <Button
                    onClick={() => setStep('diagnosis-entry')}
                    variant="outline"
                    className="px-6"
                  >
                    Back
                  </Button>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Step 4: Success */}
        {step === 'success' && (
          <Card className="border-health-green/50 bg-health-green/5">
            <CardContent className="pt-12 pb-12 text-center space-y-6">
              <div className="flex justify-center">
                <div className="rounded-full bg-health-green/20 p-6 animate-fade-in">
                  <CheckCircle2 className="w-16 h-16 text-health-green" />
                </div>
              </div>
              <div>
                <h3 className="text-2xl font-bold text-foreground mb-2">
                  Diagnosis Submitted Successfully
                </h3>
                <p className="text-muted-foreground max-w-md mx-auto">
                  Your diagnosis has been recorded and a qualified doctor is being assigned to your case. You will be notified once a doctor accepts your case.
                </p>
              </div>
              <div className="bg-blue-50 dark:bg-slate-700/50 border border-health-blue/30 rounded-lg p-4 text-sm">
                <p className="text-foreground font-semibold mb-2">What happens next:</p>
                <ul className="text-muted-foreground space-y-1 text-left max-w-md mx-auto">
                  <li>✓ AI system allocates a qualified doctor</li>
                  <li>✓ Doctor reviews your diagnosis</li>
                  <li>✓ Comprehensive diagnosis mapping is created</li>
                  <li>✓ You receive doctor's consultation</li>
                </ul>
              </div>
              <p className="text-xs text-muted-foreground">
                Redirecting to dashboard in 2 seconds...
              </p>
            </CardContent>
          </Card>
        )}
      </main>
    </div>
  );
}
