import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/use-auth';
import { validateAbhaId, validateOtp } from '@/lib/mock-data';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { AlertCircle, CheckCircle, Loader2, Lock, User } from 'lucide-react';

type LoginStep = 'abha' | 'otp' | 'success';

export default function Login() {
  const navigate = useNavigate();
  const { login } = useAuth();

  const [step, setStep] = useState<LoginStep>('abha');
  const [abhaId, setAbhaId] = useState('');
  const [otp, setOtp] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [abhaError, setAbhaError] = useState('');

  const handleAbhaSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setAbhaError('');
    setError('');

    if (!abhaId.trim()) {
      setAbhaError('Please enter your ABHA ID');
      return;
    }

    if (!validateAbhaId(abhaId)) {
      setAbhaError('Invalid ABHA ID format. Use 12 digits or XXXX-XXXX-XXXX');
      return;
    }

    // Mock OTP sending
    setStep('otp');
  };

  const handleOtpSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');

    if (!otp.trim()) {
      setError('Please enter the OTP');
      return;
    }

    if (!validateOtp(otp)) {
      setError('OTP must be 6 digits');
      return;
    }

    setLoading(true);
    try {
      await login(abhaId, otp);
      setStep('success');
      // Redirect to dashboard after brief delay
      setTimeout(() => {
        navigate('/dashboard');
      }, 1500);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Authentication failed');
      setOtp('');
    } finally {
      setLoading(false);
    }
  };

  const handleResendOtp = () => {
    // Mock resend OTP
    setError('OTP resent to your registered mobile number');
    setTimeout(() => setError(''), 3000);
  };

  const handleBackToAbha = () => {
    setStep('abha');
    setOtp('');
    setError('');
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-health-blue to-health-teal dark:from-slate-900 dark:to-slate-800 flex items-center justify-center p-4">
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-health-teal/10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-health-blue/10 rounded-full blur-3xl"></div>

      <div className="w-full max-w-md relative z-10">
        {/* Logo/Header */}
        <div className="text-center mb-8">
          <div className="flex items-center justify-center w-14 h-14 mx-auto mb-4 rounded-lg bg-white dark:bg-slate-800 shadow-lg">
            <Lock className="w-8 h-8 text-health-teal" />
          </div>
          <h1 className="text-3xl font-bold text-white mb-2">AYUSH-ICD11</h1>
          <p className="text-slate-100 text-sm">
            Dual Coding & Reciprocal Diagnosis System
          </p>
        </div>

        {/* Login Card */}
        <div className="bg-card dark:bg-slate-800 rounded-xl shadow-2xl p-8 border border-border dark:border-slate-700">
          {/* ABHA ID Step */}
          {step === 'abha' && (
            <form onSubmit={handleAbhaSubmit} className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-foreground mb-2">
                  Doctor Login
                </h2>
                <p className="text-muted-foreground text-sm">
                  Enter your ABHA ID to get started
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="abha-id" className="label-text">
                  ABHA ID
                </Label>
                <div className="relative">
                  <User className="absolute left-3 top-3.5 w-5 h-5 text-muted-foreground" />
                  <Input
                    id="abha-id"
                    type="text"
                    placeholder="123456789012 or 1234-5678-9012"
                    value={abhaId}
                    onChange={(e) => {
                      setAbhaId(e.target.value);
                      setAbhaError('');
                    }}
                    className="pl-10"
                  />
                </div>
                {abhaError && (
                  <div className="flex items-center gap-2 text-destructive text-sm mt-2">
                    <AlertCircle className="w-4 h-4" />
                    {abhaError}
                  </div>
                )}
                <p className="text-xs text-muted-foreground mt-2">
                  As per Ayushman Bharat Digital Mission (ABDM) standards
                </p>
              </div>

              <Button
                type="submit"
                className="w-full py-6 text-base font-semibold btn-primary"
              >
                Send OTP
              </Button>

              <div className="text-center text-xs text-muted-foreground">
                <p>
                  Demo OTP: <span className="font-mono font-bold">123456</span>
                </p>
              </div>
            </form>
          )}

          {/* OTP Step */}
          {step === 'otp' && (
            <form onSubmit={handleOtpSubmit} className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-foreground mb-1">
                  Verify OTP
                </h2>
                <p className="text-muted-foreground text-sm">
                  Enter the 6-digit code sent to your mobile
                </p>
              </div>

              <div className="bg-blue-50 dark:bg-slate-700/50 border border-health-blue/30 rounded-lg p-4">
                <p className="text-sm text-muted-foreground">
                  ABHA ID: <span className="font-mono font-semibold text-foreground">{abhaId}</span>
                </p>
              </div>

              <div className="space-y-2">
                <Label htmlFor="otp" className="label-text">
                  One-Time Password
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3.5 w-5 h-5 text-muted-foreground" />
                  <Input
                    id="otp"
                    type="text"
                    placeholder="000000"
                    maxLength="6"
                    value={otp}
                    onChange={(e) => {
                      setOtp(e.target.value.replace(/\D/g, ''));
                      setError('');
                    }}
                    className="pl-10 text-center text-lg tracking-widest"
                  />
                </div>
                {error && (
                  <div className="flex items-center gap-2 text-destructive text-sm mt-2">
                    <AlertCircle className="w-4 h-4" />
                    {error}
                  </div>
                )}
              </div>

              <Button
                type="submit"
                disabled={loading || otp.length !== 6}
                className="w-full py-6 text-base font-semibold btn-primary disabled:opacity-50"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Verifying...
                  </>
                ) : (
                  'Verify & Login'
                )}
              </Button>

              <div className="space-y-3">
                <button
                  type="button"
                  onClick={handleResendOtp}
                  className="w-full text-health-teal hover:text-health-teal/80 font-medium text-sm transition-colors"
                >
                  Resend OTP
                </button>
                <button
                  type="button"
                  onClick={handleBackToAbha}
                  className="w-full text-muted-foreground hover:text-foreground font-medium text-sm transition-colors"
                >
                  Change ABHA ID
                </button>
              </div>
            </form>
          )}

          {/* Success Step */}
          {step === 'success' && (
            <div className="text-center py-8 space-y-4">
              <div className="flex justify-center">
                <div className="rounded-full bg-health-green/20 p-4 animate-fade-in">
                  <CheckCircle className="w-12 h-12 text-health-green" />
                </div>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-foreground mb-2">
                  Login Successful
                </h2>
                <p className="text-muted-foreground text-sm">
                  Welcome to AYUSH-ICD11 System
                </p>
              </div>
              <p className="text-xs text-muted-foreground">
                Redirecting to dashboard...
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="text-center mt-6 text-slate-200 text-xs">
          <p>Powered by ABDM - Ayushman Bharat Digital Mission</p>
          <p className="mt-2">Government of India | Ministry of Ayush</p>
        </div>
      </div>
    </div>
  );
}
