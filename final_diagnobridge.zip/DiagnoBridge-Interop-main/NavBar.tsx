import { useNavigate } from 'react-router-dom';
import { useAuth, Doctor } from '@/hooks/use-auth';
import { Button } from '@/components/ui/button';
import { LogOut, Menu, X } from 'lucide-react';
import { useState } from 'react';

export default function NavBar() {
  const navigate = useNavigate();
  const { user, logout } = useAuth();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const handleLogout = () => {
    logout();
    navigate('/role-selection');
  };

  return (
    <nav className="bg-card dark:bg-slate-800 border-b border-border dark:border-slate-700 shadow-sm">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          {/* Logo and App Name */}
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-health-blue to-health-teal flex items-center justify-center shadow-md">
              <span className="text-white font-bold text-sm">DB</span>
            </div>
            <div>
              <h1 className="text-lg font-bold text-foreground hidden sm:block">
                DiagnoBridge
              </h1>
              <p className="text-xs text-muted-foreground hidden sm:block">
                Interop
              </p>
            </div>
          </div>

          {/* Doctor Info and Logout - Desktop */}
          <div className="hidden sm:flex items-center gap-6">
            {user && user.role === 'doctor' && (
              <div className="text-right">
                <p className="text-sm font-medium text-foreground">
                  {user.name}
                </p>
                <p className="text-xs text-muted-foreground">
                  {(user as Doctor).specialization || 'Doctor'}
                </p>
              </div>
            )}
            <button
              onClick={handleLogout}
              className="flex items-center gap-2 px-4 py-2 rounded-lg bg-destructive/10 text-destructive hover:bg-destructive/20 transition-colors font-medium text-sm"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </button>
          </div>

          {/* Mobile Menu Button */}
          <button
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="sm:hidden p-2 hover:bg-muted rounded-lg transition-colors"
          >
            {mobileMenuOpen ? (
              <X className="w-6 h-6 text-foreground" />
            ) : (
              <Menu className="w-6 h-6 text-foreground" />
            )}
          </button>
        </div>

        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="sm:hidden pb-4 border-t border-border dark:border-slate-700 pt-4">
            {user && user.role === 'doctor' && (
              <div className="mb-4 px-2 py-3 bg-muted dark:bg-slate-700/50 rounded-lg">
                <p className="text-sm font-medium text-foreground">
                  {user.name}
                </p>
                <p className="text-xs text-muted-foreground">
                  {(user as Doctor).specialization || 'Doctor'}
                </p>
              </div>
            )}
            <button
              onClick={() => {
                handleLogout();
                setMobileMenuOpen(false);
              }}
              className="w-full flex items-center gap-2 px-4 py-3 rounded-lg bg-destructive/10 text-destructive hover:bg-destructive/20 transition-colors font-medium text-sm"
            >
              <LogOut className="w-4 h-4" />
              Logout
            </button>
          </div>
        )}
      </div>
    </nav>
  );
}
