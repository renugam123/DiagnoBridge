import React, { createContext, useContext, useState, ReactNode } from 'react';

export type UserRole = 'doctor' | 'patient' | 'hospital-admin' | 'dean';

export interface Doctor {
  userId: string;
  name: string;
  abhaId: string;
  specialization?: string;
  role: 'doctor';
  email?: string;
}

export interface Patient {
  userId: string;
  name: string;
  email: string;
  phoneNumber: string;
  dateOfBirth: string;
  abhaId?: string;
  role: 'patient';
}

export interface HospitalAdmin {
  userId: string;
  name: string;
  email: string;
  hospitalName: string;
  role: 'hospital-admin';
}

export interface Dean {
  userId: string;
  name: string;
  email: string;
  institutionName: string;
  role: 'dean';
}

export type User = Doctor | Patient | HospitalAdmin | Dean;

export interface PatientRecord {
  patientId: string;
  name: string;
  abhaId: string;
  dateOfBirth: string;
  consultingDoctor: string;
}

interface AuthContextType {
  user: User | null;
  userRole: UserRole | null;
  selectedPatient: PatientRecord | null;
  isAuthenticated: boolean;
  loginAsDoctor: (abhaId: string, otp: string) => Promise<void>;
  loginAsPatient: (email: string, password: string) => Promise<void>;
  loginAsAdmin: (email: string, password: string) => Promise<void>;
  loginAsDean: (email: string, password: string) => Promise<void>;
  logout: () => void;
  setSelectedPatient: (patient: PatientRecord) => void;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [userRole, setUserRole] = useState<UserRole | null>(null);
  const [selectedPatient, setSelectedPatientState] = useState<PatientRecord | null>(null);

  const loginAsDoctor = async (abhaId: string, otp: string): Promise<void> => {
    // Mock doctor authentication
    if (otp === '123456') {
      const doctor: Doctor = {
        userId: `DOC-${Math.random().toString(36).substr(2, 9)}`,
        name: 'Dr. Rajesh Kumar',
        abhaId: abhaId,
        specialization: 'Ayurveda',
        role: 'doctor',
        email: 'dr.rajesh@hospital.com',
      };
      setUser(doctor);
      setUserRole('doctor');
      localStorage.setItem('authSession', JSON.stringify({ user: doctor, role: 'doctor' }));
    } else {
      throw new Error('Invalid OTP. Use 123456 for demo.');
    }
  };

  const loginAsPatient = async (email: string, password: string): Promise<void> => {
    // Mock patient authentication
    if (password === 'password123') {
      const patient: Patient = {
        userId: `PAT-${Math.random().toString(36).substr(2, 9)}`,
        name: 'Amit Sharma',
        email: email,
        phoneNumber: '9876543210',
        dateOfBirth: '1990-05-15',
        abhaId: '234567890123',
        role: 'patient',
      };
      setUser(patient);
      setUserRole('patient');
      localStorage.setItem('authSession', JSON.stringify({ user: patient, role: 'patient' }));
    } else {
      throw new Error('Invalid email or password. Use password123 for demo.');
    }
  };

  const loginAsAdmin = async (email: string, password: string): Promise<void> => {
    // Mock admin authentication
    if (password === 'admin123') {
      const admin: HospitalAdmin = {
        userId: `ADMIN-${Math.random().toString(36).substr(2, 9)}`,
        name: 'Priya Singh',
        email: email,
        hospitalName: 'City Medical Center',
        role: 'hospital-admin',
      };
      setUser(admin);
      setUserRole('hospital-admin');
      localStorage.setItem('authSession', JSON.stringify({ user: admin, role: 'hospital-admin' }));
    } else {
      throw new Error('Invalid credentials. Use admin123 for demo.');
    }
  };

  const loginAsDean = async (email: string, password: string): Promise<void> => {
    // Mock dean authentication
    if (password === 'dean123') {
      const dean: Dean = {
        userId: `DEAN-${Math.random().toString(36).substr(2, 9)}`,
        name: 'Dr. Vikram Patel',
        email: email,
        institutionName: 'Institute of Ayurvedic Studies',
        role: 'dean',
      };
      setUser(dean);
      setUserRole('dean');
      localStorage.setItem('authSession', JSON.stringify({ user: dean, role: 'dean' }));
    } else {
      throw new Error('Invalid credentials. Use dean123 for demo.');
    }
  };

  const logout = () => {
    setUser(null);
    setUserRole(null);
    setSelectedPatientState(null);
    localStorage.removeItem('authSession');
  };

  const setSelectedPatient = (patient: PatientRecord) => {
    setSelectedPatientState(patient);
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        userRole,
        selectedPatient,
        isAuthenticated: !!user,
        loginAsDoctor,
        loginAsPatient,
        loginAsAdmin,
        loginAsDean,
        logout,
        setSelectedPatient,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = (): AuthContextType => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};
