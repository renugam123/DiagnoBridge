import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/use-auth';
import { Button } from '@/components/ui/button';
import {
  Activity,
  Globe,
  Lock,
  Shield,
  Zap,
  ArrowRight,
  Leaf,
  Heart,
} from 'lucide-react';

export default function Home() {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();

  const handleGetStarted = () => {
    if (isAuthenticated) {
      navigate('/dashboard');
    } else {
      navigate('/role-selection');
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted dark:from-slate-900 dark:to-slate-800">
      {/* Navigation */}
      <nav className="border-b border-border dark:border-slate-700 bg-card dark:bg-slate-800/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-health-blue to-health-teal flex items-center justify-center shadow-md">
              <span className="text-white font-bold text-sm">DB</span>
            </div>
            <div>
              <h1 className="text-lg font-bold text-foreground">DiagnoBridge</h1>
              <p className="text-xs text-muted-foreground">Interop</p>
            </div>
          </div>
          <Button
            onClick={handleGetStarted}
            className="btn-primary"
          >
            {isAuthenticated ? 'Go to Dashboard' : 'Get Started'}
          </Button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          {/* Left Content */}
          <div className="space-y-6">
            <div>
              <div className="inline-block mb-4">
                <span className="px-3 py-1 rounded-full text-xs font-semibold bg-health-teal/20 text-health-teal border border-health-teal/30">
                  Complete Hospital Management
                </span>
              </div>
              <h2 className="text-5xl lg:text-6xl font-bold text-foreground leading-tight">
                Unified Diagnosis Across All
                <span className="text-transparent bg-clip-text bg-gradient-to-r from-health-blue to-health-teal ml-2">
                  Medical Systems
                </span>
              </h2>
            </div>

            <p className="text-lg text-muted-foreground leading-relaxed">
              DiagnoBridge Interop is a comprehensive hospital management system that bridges traditional and modern medical systems through intelligent reciprocal diagnosis mapping. Patients submit diagnoses in their preferred medical system, doctors are automatically assigned, and the system provides complete WHO-standardized medical details for clinical decision support.
            </p>

            <div className="flex flex-col sm:flex-row gap-4 pt-4">
              <Button
                onClick={handleGetStarted}
                className="btn-primary py-6 text-base font-semibold"
              >
                Get Started Now
                <ArrowRight className="w-4 h-4 ml-2" />
              </Button>
              <Button
                variant="outline"
                className="py-6 text-base font-semibold"
              >
                Learn More
              </Button>
            </div>

            {/* Stats */}
            <div className="grid grid-cols-3 gap-4 pt-8 border-t border-border dark:border-slate-700">
              <div>
                <p className="text-2xl font-bold text-health-teal">6+</p>
                <p className="text-sm text-muted-foreground">Medical Systems</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-health-blue">100+</p>
                <p className="text-sm text-muted-foreground">Diagnoses Mapped</p>
              </div>
              <div>
                <p className="text-2xl font-bold text-health-green">99.9%</p>
                <p className="text-sm text-muted-foreground">Accuracy</p>
              </div>
            </div>
          </div>

          {/* Right Visual */}
          <div className="relative h-96 lg:h-full hidden lg:block">
            <div className="absolute inset-0 bg-gradient-to-br from-health-blue/10 to-health-teal/10 rounded-2xl"></div>
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="w-64 h-64 bg-gradient-to-br from-health-blue to-health-teal rounded-2xl opacity-20 blur-3xl"></div>
              <div className="absolute inset-0 flex items-center justify-center">
                <div className="text-center space-y-4">
                  <Activity className="w-16 h-16 text-health-teal mx-auto opacity-80" />
                  <p className="text-sm font-semibold text-foreground opacity-60">
                    Smart Diagnosis Mapping
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="bg-card dark:bg-slate-800/50 border-y border-border dark:border-slate-700 py-20">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h3 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
              Key Features
            </h3>
            <p className="text-lg text-muted-foreground">
              Comprehensive tools for modern healthcare professionals
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {/* Feature 1 */}
            <div className="p-6 rounded-xl bg-background dark:bg-slate-900 border border-border dark:border-slate-700 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 rounded-lg bg-health-teal/20 flex items-center justify-center mb-4">
                <Globe className="w-6 h-6 text-health-teal" />
              </div>
              <h4 className="text-lg font-bold text-foreground mb-2">
                Universal Mapping
              </h4>
              <p className="text-sm text-muted-foreground">
                Convert diagnoses between Ayurveda, Siddha, Unani, Homeopathy, and
                Modern Biomedicine seamlessly.
              </p>
            </div>

            {/* Feature 2 */}
            <div className="p-6 rounded-xl bg-background dark:bg-slate-900 border border-border dark:border-slate-700 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 rounded-lg bg-health-blue/20 flex items-center justify-center mb-4">
                <Shield className="w-6 h-6 text-health-blue" />
              </div>
              <h4 className="text-lg font-bold text-foreground mb-2">
                Secure Authentication
              </h4>
              <p className="text-sm text-muted-foreground">
                ABHA ID-based authentication aligns with Ayushman Bharat Digital
                Mission standards for healthcare security.
              </p>
            </div>

            {/* Feature 3 */}
            <div className="p-6 rounded-xl bg-background dark:bg-slate-900 border border-border dark:border-slate-700 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 rounded-lg bg-health-green/20 flex items-center justify-center mb-4">
                <Zap className="w-6 h-6 text-health-green" />
              </div>
              <h4 className="text-lg font-bold text-foreground mb-2">
                Fast Diagnosis Search
              </h4>
              <p className="text-sm text-muted-foreground">
                Instant reciprocal diagnosis results with confidence scores for
                clinical decision support.
              </p>
            </div>

            {/* Feature 4 */}
            <div className="p-6 rounded-xl bg-background dark:bg-slate-900 border border-border dark:border-slate-700 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 rounded-lg bg-health-teal/20 flex items-center justify-center mb-4">
                <Heart className="w-6 h-6 text-health-teal" />
              </div>
              <h4 className="text-lg font-bold text-foreground mb-2">
                Patient-Centric Design
              </h4>
              <p className="text-sm text-muted-foreground">
                Easy access to patient information and encounter history for better
                clinical management.
              </p>
            </div>

            {/* Feature 5 */}
            <div className="p-6 rounded-xl bg-background dark:bg-slate-900 border border-border dark:border-slate-700 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 rounded-lg bg-health-blue/20 flex items-center justify-center mb-4">
                <Lock className="w-6 h-6 text-health-blue" />
              </div>
              <h4 className="text-lg font-bold text-foreground mb-2">
                Data Privacy
              </h4>
              <p className="text-sm text-muted-foreground">
                Comprehensive privacy controls and encrypted data handling compliant
                with healthcare regulations.
              </p>
            </div>

            {/* Feature 6 */}
            <div className="p-6 rounded-xl bg-background dark:bg-slate-900 border border-border dark:border-slate-700 hover:shadow-lg transition-shadow">
              <div className="w-12 h-12 rounded-lg bg-health-green/20 flex items-center justify-center mb-4">
                <Leaf className="w-6 h-6 text-health-green" />
              </div>
              <h4 className="text-lg font-bold text-foreground mb-2">
                Comprehensive Records
              </h4>
              <p className="text-sm text-muted-foreground">
                Maintain detailed encounter records with generated codes and confidence
                metrics for audit trails.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* How It Works Section */}
      <section className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
        <div className="text-center mb-16">
          <h3 className="text-3xl lg:text-4xl font-bold text-foreground mb-4">
            How It Works
          </h3>
          <p className="text-lg text-muted-foreground">
            Simple workflow for diagnosis mapping and patient documentation
          </p>
        </div>

        <div className="grid md:grid-cols-4 gap-8">
          {[
            {
              num: '1',
              title: 'Doctor Login',
              desc: 'Authenticate using ABHA ID with OTP verification',
            },
            {
              num: '2',
              title: 'Select Patient',
              desc: 'Choose or load patient information into the system',
            },
            {
              num: '3',
              title: 'Search Diagnosis',
              desc: 'Enter diagnosis in your preferred medical system',
            },
            {
              num: '4',
              title: 'Save & Document',
              desc: 'Review mapping results and save the encounter',
            },
          ].map((step, idx) => (
            <div key={idx} className="relative">
              <div className="text-center">
                <div className="inline-flex items-center justify-center w-12 h-12 rounded-full bg-health-teal text-white font-bold text-lg mb-4">
                  {step.num}
                </div>
                <h4 className="text-lg font-bold text-foreground mb-2">
                  {step.title}
                </h4>
                <p className="text-sm text-muted-foreground">{step.desc}</p>
              </div>
              {idx < 3 && (
                <div className="hidden md:block absolute top-6 -right-4 text-health-teal opacity-20">
                  <ArrowRight className="w-8 h-8" />
                </div>
              )}
            </div>
          ))}
        </div>
      </section>

      {/* CTA Section */}
      <section className="bg-gradient-to-r from-health-blue to-health-teal dark:from-slate-800 dark:to-slate-700 py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h3 className="text-3xl lg:text-4xl font-bold text-white mb-4">
            Ready to Get Started?
          </h3>
          <p className="text-lg text-white/90 mb-8">
            Transform your diagnosis coding with AYUSH-ICD11. Log in now and experience
            the power of integrated medical systems.
          </p>
          <Button
            onClick={() => navigate('/role-selection')}
            className="bg-white text-health-blue hover:bg-white/90 py-6 px-8 text-base font-semibold"
          >
            Get Started
            <ArrowRight className="w-4 h-4 ml-2" />
          </Button>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-card dark:bg-slate-900 border-t border-border dark:border-slate-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="grid md:grid-cols-3 gap-8 mb-8 pb-8 border-b border-border dark:border-slate-700">
            <div>
              <h4 className="font-bold text-foreground mb-4">About AYUSH-ICD11</h4>
              <p className="text-sm text-muted-foreground">
                A unified diagnosis system compliant with Ayushman Bharat Digital
                Mission standards.
              </p>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">Standards</h4>
              <ul className="text-sm text-muted-foreground space-y-2">
                <li>ABDM Compliant</li>
                <li>ICD-11 Compatible</li>
                <li>NAMASTE Coded</li>
              </ul>
            </div>
            <div>
              <h4 className="font-bold text-foreground mb-4">Organization</h4>
              <p className="text-sm text-muted-foreground">
                Government of India
                <br />
                Ministry of Ayush
              </p>
            </div>
          </div>
          <div className="text-center text-sm text-muted-foreground">
            <p>
              © 2024 AYUSH-ICD11 System. All rights reserved. Powered by Ayushman
              Bharat Digital Mission
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
