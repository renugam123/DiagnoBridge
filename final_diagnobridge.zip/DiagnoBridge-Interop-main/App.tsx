import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AuthProvider } from "@/hooks/use-auth";

// Pages
import Home from "./pages/Home";
import RoleSelection from "./pages/RoleSelection";
import LoginDoctor from "./pages/LoginDoctor";
import LoginPatient from "./pages/LoginPatient";
import LoginAdmin from "./pages/LoginAdmin";
import LoginDean from "./pages/LoginDean";
import Dashboard from "./pages/Dashboard";
import SaveEncounter from "./pages/SaveEncounter";
import SavedEncounters from "./pages/SavedEncounters";
import PatientDashboard from "./pages/PatientDashboard";
import PatientDiagnosisPortal from "./pages/PatientDiagnosisPortal";
import AdminDashboard from "./pages/AdminDashboard";
import DeanDashboard from "./pages/DeanDashboard";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/role-selection" element={<RoleSelection />} />
            
            {/* Role-based login routes */}
            <Route path="/login/doctor" element={<LoginDoctor />} />
            <Route path="/login/patient" element={<LoginPatient />} />
            <Route path="/login/admin" element={<LoginAdmin />} />
            <Route path="/login/dean" element={<LoginDean />} />
            
            {/* Doctor routes */}
            <Route path="/dashboard" element={<Dashboard />} />
            <Route path="/save-encounter" element={<SaveEncounter />} />
            <Route path="/saved-encounters" element={<SavedEncounters />} />
            
            {/* Patient routes */}
            <Route path="/patient-dashboard" element={<PatientDashboard />} />
            <Route path="/patient-diagnosis" element={<PatientDiagnosisPortal />} />

            {/* Admin routes */}
            <Route path="/admin-dashboard" element={<AdminDashboard />} />

            {/* Dean routes */}
            <Route path="/dean-dashboard" element={<DeanDashboard />} />
            
            {/* ADD ALL CUSTOM ROUTES ABOVE THE CATCH-ALL "*" ROUTE */}
            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
      </TooltipProvider>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
