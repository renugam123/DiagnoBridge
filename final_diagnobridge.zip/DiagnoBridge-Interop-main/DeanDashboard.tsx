import { useNavigate } from 'react-router-dom';
import { useAuth, Dean } from '@/hooks/use-auth';
import NavBar from '@/components/NavBar';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  GraduationCap,
  TrendingUp,
  FileText,
  Users,
  BarChart3,
  Settings,
  AlertCircle,
} from 'lucide-react';
import { useEffect } from 'react';

export default function DeanDashboard() {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/role-selection');
      return;
    }
  }, [isAuthenticated, navigate]);

  const dean = user as Dean;

  // Mock institutional statistics
  const stats = [
    {
      label: 'Total Institutions',
      value: '8',
      icon: GraduationCap,
      color: 'bg-amber-600',
    },
    {
      label: 'Registered Doctors',
      value: '342',
      icon: Users,
      color: 'bg-health-blue',
    },
    {
      label: 'Active Patients',
      value: '5,234',
      icon: TrendingUp,
      color: 'bg-health-green',
    },
    {
      label: 'Pending Reports',
      value: '23',
      icon: FileText,
      color: 'bg-amber-500',
    },
  ];

  const institutions = [
    {
      name: 'Institute of Ayurvedic Studies',
      type: 'Medical Institute',
      doctors: 45,
      patients: 1200,
      status: 'Active',
    },
    {
      name: 'City Medical College',
      type: 'Educational Institution',
      doctors: 78,
      patients: 2100,
      status: 'Active',
    },
    {
      name: 'Central Hospital',
      type: 'Healthcare Facility',
      doctors: 120,
      patients: 1934,
      status: 'Active',
    },
  ];

  const reports = [
    {
      id: '1',
      title: 'Annual Clinical Performance Report',
      date: '2024-01-20',
      status: 'Pending',
    },
    {
      id: '2',
      title: 'System Utilization Statistics',
      date: '2024-01-15',
      status: 'Completed',
    },
    {
      id: '3',
      title: 'Diagnosis Mapping Accuracy Analysis',
      date: '2024-01-10',
      status: 'Completed',
    },
  ];

  return (
    <div className="min-h-screen bg-background dark:bg-slate-900">
      <NavBar />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-foreground mb-2">
            Institutional Oversight Dashboard
          </h2>
          <p className="text-muted-foreground">
            System-wide management and policy oversight for {dean.institutionName}
          </p>
        </div>

        {/* Institution Info Card */}
        <Card className="mb-8 bg-gradient-to-br from-amber-500/5 to-orange-500/5 dark:from-slate-800 dark:to-slate-800 border-amber-300/30 dark:border-amber-700/30">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-lg bg-amber-600/20 flex items-center justify-center">
                  <GraduationCap className="w-6 h-6 text-amber-600" />
                </div>
                <div>
                  <CardTitle>{dean.institutionName}</CardTitle>
                  <CardDescription>Dean: {dean.name}</CardDescription>
                </div>
              </div>
              <Badge className="bg-amber-600/20 text-amber-600 border-0">
                Operational
              </Badge>
            </div>
          </CardHeader>
        </Card>

        {/* Statistics Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {stats.map((stat, idx) => {
            const IconComponent = stat.icon;
            return (
              <Card key={idx}>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">
                        {stat.label}
                      </p>
                      <p className="text-3xl font-bold text-foreground">
                        {stat.value}
                      </p>
                    </div>
                    <div className={`${stat.color} p-3 rounded-lg text-white`}>
                      <IconComponent className="w-6 h-6" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Institutional Network */}
        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          {/* Affiliated Institutions */}
          <Card>
            <CardHeader>
              <CardTitle>Affiliated Institutions</CardTitle>
              <CardDescription>Network of institutions under oversight</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {institutions.map((inst, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-4 bg-muted dark:bg-slate-800 rounded-lg border border-border dark:border-slate-700"
                  >
                    <div className="flex-1">
                      <h4 className="font-semibold text-foreground">
                        {inst.name}
                      </h4>
                      <p className="text-xs text-muted-foreground mt-1">
                        {inst.type}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {inst.doctors} doctors • {inst.patients} patients
                      </p>
                    </div>
                    <Badge className="bg-health-green/20 text-health-green border-0">
                      {inst.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Reports */}
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle>Reports & Analytics</CardTitle>
                  <CardDescription>Institutional reports and metrics</CardDescription>
                </div>
                <Button variant="ghost" size="sm">
                  View All
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {reports.map((report) => (
                  <div
                    key={report.id}
                    className="flex items-center justify-between p-4 bg-muted dark:bg-slate-800 rounded-lg border border-border dark:border-slate-700"
                  >
                    <div className="flex-1">
                      <h4 className="font-semibold text-foreground mb-1">
                        {report.title}
                      </h4>
                      <p className="text-xs text-muted-foreground">
                        {new Date(report.date).toLocaleDateString('en-IN', {
                          year: 'numeric',
                          month: 'short',
                          day: 'numeric',
                        })}
                      </p>
                    </div>
                    <Badge
                      variant="secondary"
                      className={
                        report.status === 'Completed'
                          ? 'bg-health-green/20 text-health-green border-0'
                          : 'bg-amber-600/20 text-amber-600 border-0'
                      }
                    >
                      {report.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Policy & Governance */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Policy & Governance</CardTitle>
            <CardDescription>Institutional policies and compliance</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="grid md:grid-cols-2 gap-4">
              <div className="p-4 bg-muted dark:bg-slate-800 rounded-lg border border-border dark:border-slate-700">
                <h4 className="font-semibold text-foreground mb-2">
                  Data Standards Compliance
                </h4>
                <div className="w-full bg-border dark:bg-slate-700 rounded-full h-2">
                  <div className="bg-health-green h-2 rounded-full" style={{ width: '92%' }}></div>
                </div>
                <p className="text-xs text-muted-foreground mt-2">92% Compliant</p>
              </div>
              <div className="p-4 bg-muted dark:bg-slate-800 rounded-lg border border-border dark:border-slate-700">
                <h4 className="font-semibold text-foreground mb-2">
                  System Uptime
                </h4>
                <div className="w-full bg-border dark:bg-slate-700 rounded-full h-2">
                  <div className="bg-health-green h-2 rounded-full" style={{ width: '99.8%' }}></div>
                </div>
                <p className="text-xs text-muted-foreground mt-2">99.8% Uptime</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Action Buttons */}
        <Card>
          <CardHeader>
            <CardTitle>Administrative Actions</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-3">
            <Button className="bg-amber-600 hover:bg-amber-700">
              <FileText className="w-4 h-4 mr-2" />
              Generate Report
            </Button>
            <Button variant="outline">
              <BarChart3 className="w-4 h-4 mr-2" />
              View Analytics
            </Button>
            <Button variant="outline">
              <Settings className="w-4 h-4 mr-2" />
              System Settings
            </Button>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
