import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth, Doctor, PatientRecord } from '@/hooks/use-auth';
import NavBar from '@/components/NavBar';
import { searchDiagnosis, DiagnosisMapping, medicalSystems } from '@/lib/mock-data';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  AlertCircle,
  CheckCircle2,
  FileText,
  History,
  Search,
  User,
  Stethoscope,
} from 'lucide-react';

export default function Dashboard() {
  const navigate = useNavigate();
  const { user, isAuthenticated, selectedPatient, setSelectedPatient } = useAuth();

  const [selectedSystem, setSelectedSystem] = useState('Modern Biomedicine');
  const [searchTerm, setSearchTerm] = useState('');
  const [diagnosisResult, setDiagnosisResult] = useState<DiagnosisMapping | null>(
    null
  );
  const [showResult, setShowResult] = useState(false);
  const [mockPatient, setMockPatient] = useState<PatientRecord | null>(selectedPatient);

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/role-selection');
      return;
    }

    // Initialize with mock patient if not already set
    if (!selectedPatient) {
      const newPatient: PatientRecord = {
        patientId: `PAT-${Math.random().toString(36).substr(2, 9)}`,
        name: 'Amit Sharma',
        abhaId: '234567890123',
        dateOfBirth: '1980-05-15',
        consultingDoctor: (user as Doctor)?.name || 'Dr. Rajesh Kumar',
      };
      setMockPatient(newPatient);
      setSelectedPatient(newPatient);
    }
  }, [isAuthenticated, navigate, user, selectedPatient, setSelectedPatient]);

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!searchTerm.trim()) {
      return;
    }

    const result = searchDiagnosis(searchTerm);
    setDiagnosisResult(result || null);
    setShowResult(true);
  };

  const handleSaveEncounter = () => {
    if (diagnosisResult) {
      navigate('/save-encounter', {
        state: { diagnosis: diagnosisResult },
      });
    }
  };

  const handleViewSavedEncounters = () => {
    navigate('/saved-encounters');
  };

  const currentPatient = mockPatient || selectedPatient;

  return (
    <div className="min-h-screen bg-background dark:bg-slate-900">
      <NavBar />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-foreground mb-2">
            Doctor Dashboard
          </h2>
          <p className="text-muted-foreground">
            Welcome, {(user as Doctor)?.name || 'Doctor'}. Manage diagnoses and patient records below.
          </p>
        </div>

        {/* Patient Information Card */}
        {currentPatient && (
          <Card className="mb-8 bg-gradient-to-br from-health-blue/5 to-health-teal/5 dark:from-slate-800 dark:to-slate-800 border-health-teal/30">
            <CardHeader className="pb-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="w-12 h-12 rounded-full bg-health-teal/20 flex items-center justify-center">
                    <User className="w-6 h-6 text-health-teal" />
                  </div>
                  <div>
                    <CardTitle className="text-xl">Current Patient</CardTitle>
                    <CardDescription>Patient Information</CardDescription>
                  </div>
                </div>
                <Badge className="bg-health-green/20 text-health-green border-0">
                  Active
                </Badge>
              </div>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">
                    Patient Name
                  </Label>
                  <p className="font-semibold text-foreground">
                    {currentPatient.name}
                  </p>
                </div>
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">
                    ABHA ID
                  </Label>
                  <p className="font-mono font-semibold text-foreground">
                    {currentPatient.abhaId}
                  </p>
                </div>
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">
                    Date of Birth
                  </Label>
                  <p className="font-semibold text-foreground">
                    {new Date(currentPatient.dateOfBirth).toLocaleDateString(
                      'en-IN',
                      {
                        year: 'numeric',
                        month: 'long',
                        day: 'numeric',
                      }
                    )}
                  </p>
                </div>
                <div className="space-y-1">
                  <Label className="text-xs text-muted-foreground">
                    Consulting Doctor
                  </Label>
                  <p className="font-semibold text-foreground">
                    {currentPatient.consultingDoctor}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Main Diagnosis Search Section */}
        <Card className="mb-8 border-health-teal/30">
          <CardHeader>
            <div className="flex items-center gap-2">
              <Stethoscope className="w-5 h-5 text-health-teal" />
              <div>
                <CardTitle>Diagnosis Search</CardTitle>
                <CardDescription>
                  Enter diagnosis term from any medical system
                </CardDescription>
              </div>
            </div>
          </CardHeader>
          <CardContent className="space-y-6">
            <form onSubmit={handleSearch} className="space-y-4">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="medical-system" className="label-text">
                    Medical System
                  </Label>
                  <Select value={selectedSystem} onValueChange={setSelectedSystem}>
                    <SelectTrigger id="medical-system">
                      <SelectValue placeholder="Select system" />
                    </SelectTrigger>
                    <SelectContent>
                      {medicalSystems.map((system) => (
                        <SelectItem key={system} value={system}>
                          {system}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="diagnosis-term" className="label-text">
                    Diagnosis Term
                  </Label>
                  <div className="relative">
                    <Search className="absolute left-3 top-3.5 w-5 h-5 text-muted-foreground" />
                    <Input
                      id="diagnosis-term"
                      type="text"
                      placeholder="e.g., Jvara, Diabetes, Fever"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10"
                    />
                  </div>
                </div>
              </div>

              <Button
                type="submit"
                disabled={!searchTerm.trim()}
                className="w-full sm:w-auto btn-primary py-6 font-semibold"
              >
                <Search className="w-4 h-4 mr-2" />
                Search Diagnosis
              </Button>
            </form>

            {/* Diagnosis Result */}
            {showResult && diagnosisResult ? (
              <div className="mt-6 p-6 bg-gradient-to-br from-health-green/5 to-health-teal/5 dark:from-slate-800 dark:to-slate-800 rounded-lg border border-health-green/30">
                <div className="flex items-start gap-3 mb-4">
                  <CheckCircle2 className="w-5 h-5 text-health-green mt-0.5 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <h3 className="font-bold text-lg text-foreground mb-2">
                      Reciprocal Coding Result Found
                    </h3>

                    {/* NAMASTE Code */}
                    <div className="mb-4 p-3 bg-white dark:bg-slate-700/50 rounded border border-border dark:border-slate-600">
                      <Label className="text-xs text-muted-foreground">
                        NAMASTE (AYUSH) Code
                      </Label>
                      <p className="font-mono font-bold text-lg text-health-blue mt-1">
                        {diagnosisResult.namaste.code}
                      </p>
                      <p className="text-sm text-foreground mt-1">
                        {diagnosisResult.namaste.name}
                      </p>
                    </div>

                    {/* ICD-11 Codes */}
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mb-4">
                      <div className="p-3 bg-white dark:bg-slate-700/50 rounded border border-border dark:border-slate-600">
                        <Label className="text-xs text-muted-foreground">
                          ICD-11 TM2 Code
                        </Label>
                        <p className="font-mono font-bold text-lg text-health-teal mt-1">
                          {diagnosisResult.icd11tm2.code}
                        </p>
                        <div className="flex items-center justify-between mt-2">
                          <span className="text-xs text-foreground">
                            {diagnosisResult.icd11tm2.name}
                          </span>
                          <Badge className="bg-health-teal/20 text-health-teal border-0">
                            {Math.round(diagnosisResult.icd11tm2.confidence * 100)}%
                          </Badge>
                        </div>
                      </div>

                      <div className="p-3 bg-white dark:bg-slate-700/50 rounded border border-border dark:border-slate-600">
                        <Label className="text-xs text-muted-foreground">
                          ICD-11 Biomedical
                        </Label>
                        <p className="font-mono font-bold text-lg text-health-blue mt-1">
                          {diagnosisResult.icd11biomedical.code}
                        </p>
                        <div className="flex items-center justify-between mt-2">
                          <span className="text-xs text-foreground">
                            {diagnosisResult.icd11biomedical.name}
                          </span>
                          <Badge className="bg-health-blue/20 text-health-blue border-0">
                            {Math.round(diagnosisResult.icd11biomedical.confidence * 100)}%
                          </Badge>
                        </div>
                      </div>
                    </div>

                    {/* Description */}
                    <div className="mb-4">
                      <Label className="text-xs text-muted-foreground">
                        Clinical Description
                      </Label>
                      <p className="text-sm text-foreground mt-2">
                        {diagnosisResult.description}
                      </p>
                    </div>

                    {/* WHO Details */}
                    {diagnosisResult.whoDetails && (
                      <div className="mb-4 p-4 bg-blue-50 dark:bg-slate-700/30 rounded border border-health-blue/20 dark:border-health-blue/10">
                        <Label className="text-xs text-muted-foreground font-bold mb-3 block">
                          WHO CLINICAL DETAILS
                        </Label>
                        <div className="space-y-3 text-sm">
                          <div>
                            <p className="font-semibold text-foreground mb-1">Definition:</p>
                            <p className="text-muted-foreground">
                              {diagnosisResult.whoDetails.definition}
                            </p>
                          </div>
                          <div>
                            <p className="font-semibold text-foreground mb-1">Common Symptoms:</p>
                            <ul className="text-muted-foreground list-disc list-inside space-y-0.5">
                              {diagnosisResult.whoDetails.symptoms.map((symptom, idx) => (
                                <li key={idx}>{symptom}</li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <p className="font-semibold text-foreground mb-1">Risk Factors:</p>
                            <ul className="text-muted-foreground list-disc list-inside space-y-0.5">
                              {diagnosisResult.whoDetails.riskFactors.map((factor, idx) => (
                                <li key={idx}>{factor}</li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <p className="font-semibold text-foreground mb-1">Prevention Measures:</p>
                            <ul className="text-muted-foreground list-disc list-inside space-y-0.5">
                              {diagnosisResult.whoDetails.prevention.map((measure, idx) => (
                                <li key={idx}>{measure}</li>
                              ))}
                            </ul>
                          </div>
                          <div>
                            <p className="font-semibold text-foreground mb-1">Treatment Options:</p>
                            <ul className="text-muted-foreground list-disc list-inside space-y-0.5">
                              {diagnosisResult.whoDetails.treatment.map((option, idx) => (
                                <li key={idx}>{option}</li>
                              ))}
                            </ul>
                          </div>
                        </div>
                      </div>
                    )}

                    {/* Synonyms */}
                    <div>
                      <Label className="text-xs text-muted-foreground">
                        Synonyms
                      </Label>
                      <div className="flex flex-wrap gap-2 mt-2">
                        {diagnosisResult.synonyms.map((synonym) => (
                          <Badge key={synonym} variant="secondary">
                            {synonym}
                          </Badge>
                        ))}
                      </div>
                    </div>

                    {/* Action Buttons */}
                    <div className="flex gap-3 mt-6">
                      <Button
                        onClick={handleSaveEncounter}
                        className="flex-1 btn-primary py-5 font-semibold"
                      >
                        <FileText className="w-4 h-4 mr-2" />
                        Save Encounter
                      </Button>
                    </div>
                  </div>
                </div>
              </div>
            ) : showResult && !diagnosisResult ? (
              <div className="mt-6 p-6 bg-amber-50 dark:bg-amber-900/20 rounded-lg border border-amber-300/50 dark:border-amber-700/50">
                <div className="flex items-start gap-3">
                  <AlertCircle className="w-5 h-5 text-amber-600 dark:text-amber-500 mt-0.5 flex-shrink-0" />
                  <div>
                    <h3 className="font-semibold text-amber-900 dark:text-amber-100">
                      No Results Found
                    </h3>
                    <p className="text-sm text-amber-800 dark:text-amber-200 mt-1">
                      Try searching with different terminology or check the spelling of
                      your diagnosis term.
                    </p>
                  </div>
                </div>
              </div>
            ) : null}
          </CardContent>
        </Card>

        {/* Quick Actions */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <History className="w-5 h-5 text-health-teal" />
              Quick Actions
            </CardTitle>
          </CardHeader>
          <CardContent>
            <Button
              onClick={handleViewSavedEncounters}
              variant="outline"
              className="w-full sm:w-auto"
            >
              <History className="w-4 h-4 mr-2" />
              View Saved Encounters
            </Button>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
