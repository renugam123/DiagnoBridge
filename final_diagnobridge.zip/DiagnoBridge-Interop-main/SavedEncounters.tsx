import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/use-auth';
import NavBar from '@/components/NavBar';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { AlertCircle, ArrowLeft, FileText } from 'lucide-react';

export default function SavedEncounters() {
  const navigate = useNavigate();
  const { isAuthenticated } = useAuth();

  if (!isAuthenticated) {
    navigate('/role-selection');
    return null;
  }

  return (
    <div className="min-h-screen bg-background dark:bg-slate-900">
      <NavBar />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Button
          onClick={() => navigate('/dashboard')}
          variant="ghost"
          className="mb-6"
        >
          <ArrowLeft className="w-4 h-4 mr-2" />
          Back to Dashboard
        </Button>

        <div className="mb-8">
          <h2 className="text-3xl font-bold text-foreground mb-2">
            Saved Encounters
          </h2>
          <p className="text-muted-foreground">
            View and manage all diagnosis encounters for your patients
          </p>
        </div>

        <div className="space-y-6">
          {/* Empty State */}
          <Card>
            <CardHeader>
              <CardTitle>Encounter History</CardTitle>
              <CardDescription>
                All saved diagnoses and mappings
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-12">
                <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-muted mb-4">
                  <FileText className="w-8 h-8 text-muted-foreground" />
                </div>
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  No Encounters Yet
                </h3>
                <p className="text-muted-foreground mb-6 max-w-md mx-auto">
                  You haven't saved any diagnosis encounters yet. Start by searching
                  for a diagnosis on the dashboard.
                </p>
                <Button
                  onClick={() => navigate('/dashboard')}
                  className="btn-primary"
                >
                  Go to Dashboard
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Feature Info */}
          <Card>
            <CardHeader>
              <CardTitle className="flex items-center gap-2">
                <AlertCircle className="w-5 h-5 text-blue-600" />
                Feature Coming Soon
              </CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-muted-foreground mb-4">
                The Saved Encounters page is under development and will include:
              </p>
              <ul className="text-sm text-muted-foreground space-y-2 ml-4 list-disc">
                <li>List of all diagnosis encounters with timestamps</li>
                <li>Search and filter capabilities</li>
                <li>View detailed encounter information</li>
                <li>Generate and download encounter reports</li>
                <li>Export data for clinical documentation</li>
                <li>Audit trail of all modifications</li>
              </ul>
            </CardContent>
          </Card>
        </div>
      </main>
    </div>
  );
}
