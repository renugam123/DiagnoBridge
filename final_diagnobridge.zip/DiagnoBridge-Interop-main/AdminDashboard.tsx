import { useNavigate } from 'react-router-dom';
import { useAuth, HospitalAdmin } from '@/hooks/use-auth';
import NavBar from '@/components/NavBar';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import {
  Users,
  Building2,
  TrendingUp,
  AlertCircle,
  Settings,
  BarChart3,
} from 'lucide-react';
import { useEffect } from 'react';

export default function AdminDashboard() {
  const navigate = useNavigate();
  const { user, isAuthenticated } = useAuth();

  useEffect(() => {
    if (!isAuthenticated) {
      navigate('/role-selection');
      return;
    }
  }, [isAuthenticated, navigate]);

  const admin = user as HospitalAdmin;

  // Mock statistics
  const stats = [
    {
      label: 'Total Patients',
      value: '1,234',
      icon: Users,
      color: 'bg-health-teal',
    },
    {
      label: 'Active Doctors',
      value: '45',
      icon: Users,
      color: 'bg-health-blue',
    },
    {
      label: 'Consultations Today',
      value: '87',
      icon: TrendingUp,
      color: 'bg-health-green',
    },
    {
      label: 'Pending Cases',
      value: '12',
      icon: AlertCircle,
      color: 'bg-amber-600',
    },
  ];

  const recentActivities = [
    {
      id: '1',
      type: 'Patient Admission',
      description: 'New patient admitted to ward A',
      timestamp: '2024-01-20 10:30 AM',
      status: 'Completed',
    },
    {
      id: '2',
      type: 'Doctor Assignment',
      description: 'Dr. Rajesh Kumar assigned to case #1234',
      timestamp: '2024-01-20 09:15 AM',
      status: 'Completed',
    },
    {
      id: '3',
      type: 'System Alert',
      description: 'Backup process completed successfully',
      timestamp: '2024-01-20 08:00 AM',
      status: 'Info',
    },
  ];

  const departments = [
    { name: 'Ayurveda', doctors: 12, patients: 234 },
    { name: 'Modern Medicine', doctors: 18, patients: 567 },
    { name: 'Siddha', doctors: 8, patients: 156 },
    { name: 'Unani', doctors: 7, patients: 145 },
  ];

  return (
    <div className="min-h-screen bg-background dark:bg-slate-900">
      <NavBar />

      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Page Header */}
        <div className="mb-8">
          <h2 className="text-3xl font-bold text-foreground mb-2">
            Hospital Administration Dashboard
          </h2>
          <p className="text-muted-foreground">
            Manage operations and oversee clinical workflows at {admin.hospitalName}
          </p>
        </div>

        {/* Hospital Info Card */}
        <Card className="mb-8 bg-gradient-to-br from-health-green/5 to-emerald-500/5 dark:from-slate-800 dark:to-slate-800 border-health-green/30">
          <CardHeader>
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-3">
                <div className="w-12 h-12 rounded-lg bg-health-green/20 flex items-center justify-center">
                  <Building2 className="w-6 h-6 text-health-green" />
                </div>
                <div>
                  <CardTitle>{admin.hospitalName}</CardTitle>
                  <CardDescription>Admin: {admin.name}</CardDescription>
                </div>
              </div>
              <Badge className="bg-health-green/20 text-health-green border-0">
                Operational
              </Badge>
            </div>
          </CardHeader>
        </Card>

        {/* Statistics Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {stats.map((stat, idx) => {
            const IconComponent = stat.icon;
            return (
              <Card key={idx}>
                <CardContent className="pt-6">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm text-muted-foreground mb-1">
                        {stat.label}
                      </p>
                      <p className="text-3xl font-bold text-foreground">
                        {stat.value}
                      </p>
                    </div>
                    <div className={`${stat.color} p-3 rounded-lg text-white`}>
                      <IconComponent className="w-6 h-6" />
                    </div>
                  </div>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Management Sections */}
        <div className="grid lg:grid-cols-2 gap-8 mb-8">
          {/* Departments */}
          <Card>
            <CardHeader>
              <CardTitle>Departments</CardTitle>
              <CardDescription>Hospital departments and staffing</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {departments.map((dept, idx) => (
                  <div
                    key={idx}
                    className="flex items-center justify-between p-4 bg-muted dark:bg-slate-800 rounded-lg border border-border dark:border-slate-700"
                  >
                    <div>
                      <h4 className="font-semibold text-foreground">{dept.name}</h4>
                      <p className="text-sm text-muted-foreground">
                        {dept.doctors} doctors • {dept.patients} patients
                      </p>
                    </div>
                    <Button variant="ghost" size="sm">
                      Manage
                    </Button>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>

          {/* Recent Activities */}
          <Card>
            <CardHeader>
              <CardTitle>Recent Activities</CardTitle>
              <CardDescription>Latest hospital operations</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivities.map((activity) => (
                  <div
                    key={activity.id}
                    className="flex items-start gap-3 p-4 bg-muted dark:bg-slate-800 rounded-lg border border-border dark:border-slate-700"
                  >
                    <div className="flex-1">
                      <h4 className="font-semibold text-foreground mb-1">
                        {activity.type}
                      </h4>
                      <p className="text-sm text-muted-foreground mb-2">
                        {activity.description}
                      </p>
                      <p className="text-xs text-muted-foreground">
                        {activity.timestamp}
                      </p>
                    </div>
                    <Badge
                      variant="secondary"
                      className={
                        activity.status === 'Completed'
                          ? 'bg-health-green/20 text-health-green border-0'
                          : 'bg-health-blue/20 text-health-blue border-0'
                      }
                    >
                      {activity.status}
                    </Badge>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Action Buttons */}
        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-3">
            <Button className="bg-health-green hover:bg-health-green/90">
              <Users className="w-4 h-4 mr-2" />
              Manage Staff
            </Button>
            <Button variant="outline">
              <BarChart3 className="w-4 h-4 mr-2" />
              View Reports
            </Button>
            <Button variant="outline">
              <Settings className="w-4 h-4 mr-2" />
              Settings
            </Button>
          </CardContent>
        </Card>
      </main>
    </div>
  );
}
