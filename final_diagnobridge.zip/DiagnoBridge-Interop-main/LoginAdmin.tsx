import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/hooks/use-auth';
import { validateEmail } from '@/lib/mock-data';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { AlertCircle, CheckCircle, Loader2, Lock, Mail, ArrowLeft } from 'lucide-react';

type LoginStep = 'credentials' | 'success';

export default function LoginAdmin() {
  const navigate = useNavigate();
  const { loginAsAdmin } = useAuth();

  const [step, setStep] = useState<LoginStep>('credentials');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [emailError, setEmailError] = useState('');
  const [passwordError, setPasswordError] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setEmailError('');
    setPasswordError('');
    setError('');

    if (!email.trim()) {
      setEmailError('Please enter your email');
      return;
    }

    if (!validateEmail(email)) {
      setEmailError('Please enter a valid email address');
      return;
    }

    if (!password.trim()) {
      setPasswordError('Please enter your password');
      return;
    }

    if (password.length < 6) {
      setPasswordError('Password must be at least 6 characters');
      return;
    }

    setLoading(true);
    try {
      await loginAsAdmin(email, password);
      setStep('success');
      setTimeout(() => {
        navigate('/admin-dashboard');
      }, 1500);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Login failed');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-health-green to-emerald-600 dark:from-slate-900 dark:to-slate-800 flex items-center justify-center p-4">
      {/* Decorative elements */}
      <div className="absolute top-0 right-0 w-64 h-64 bg-health-green/10 rounded-full blur-3xl"></div>
      <div className="absolute bottom-0 left-0 w-64 h-64 bg-emerald-600/10 rounded-full blur-3xl"></div>

      <div className="w-full max-w-md relative z-10">
        {/* Header */}
        <div className="mb-8">
          <Button
            onClick={() => navigate('/role-selection')}
            variant="ghost"
            className="text-white hover:bg-white/20 mb-6"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back
          </Button>

          <div className="text-center">
            <div className="flex items-center justify-center w-14 h-14 mx-auto mb-4 rounded-lg bg-white dark:bg-slate-800 shadow-lg">
              <Lock className="w-8 h-8 text-health-green" />
            </div>
            <h1 className="text-3xl font-bold text-white mb-2">Hospital Admin</h1>
            <p className="text-slate-100 text-sm">
              Healthcare facility management portal
            </p>
          </div>
        </div>

        {/* Login Card */}
        <div className="bg-card dark:bg-slate-800 rounded-xl shadow-2xl p-8 border border-border dark:border-slate-700">
          {/* Login Form */}
          {step === 'credentials' && (
            <form onSubmit={handleSubmit} className="space-y-6">
              <div>
                <h2 className="text-2xl font-bold text-foreground mb-2">
                  Admin Portal
                </h2>
                <p className="text-muted-foreground text-sm">
                  Hospital administration and management
                </p>
              </div>

              <div className="bg-green-50 dark:bg-slate-700/50 border border-health-green/30 rounded-lg p-4 text-sm text-muted-foreground">
                <p className="font-semibold text-foreground mb-2">Admin Features:</p>
                <ul className="space-y-1 text-xs">
                  <li>• Hospital operations management</li>
                  <li>• Doctor and staff management</li>
                  <li>• Patient records overview</li>
                  <li>• System analytics and reports</li>
                </ul>
              </div>

              <div className="space-y-2">
                <Label htmlFor="email" className="label-text">
                  Email Address
                </Label>
                <div className="relative">
                  <Mail className="absolute left-3 top-3.5 w-5 h-5 text-muted-foreground" />
                  <Input
                    id="email"
                    type="email"
                    placeholder="admin@hospital.com"
                    value={email}
                    onChange={(e) => {
                      setEmail(e.target.value);
                      setEmailError('');
                    }}
                    className="pl-10"
                  />
                </div>
                {emailError && (
                  <div className="flex items-center gap-2 text-destructive text-sm mt-2">
                    <AlertCircle className="w-4 h-4" />
                    {emailError}
                  </div>
                )}
              </div>

              <div className="space-y-2">
                <Label htmlFor="password" className="label-text">
                  Password
                </Label>
                <div className="relative">
                  <Lock className="absolute left-3 top-3.5 w-5 h-5 text-muted-foreground" />
                  <Input
                    id="password"
                    type="password"
                    placeholder="Enter your password"
                    value={password}
                    onChange={(e) => {
                      setPassword(e.target.value);
                      setPasswordError('');
                    }}
                    className="pl-10"
                  />
                </div>
                {passwordError && (
                  <div className="flex items-center gap-2 text-destructive text-sm mt-2">
                    <AlertCircle className="w-4 h-4" />
                    {passwordError}
                  </div>
                )}
              </div>

              {error && (
                <div className="flex items-center gap-2 text-destructive text-sm bg-destructive/10 p-3 rounded-lg">
                  <AlertCircle className="w-4 h-4 flex-shrink-0" />
                  {error}
                </div>
              )}

              <Button
                type="submit"
                disabled={loading}
                className="w-full py-6 text-base font-semibold bg-health-green hover:bg-health-green/90 text-white disabled:opacity-50"
              >
                {loading ? (
                  <>
                    <Loader2 className="w-4 h-4 mr-2 animate-spin" />
                    Signing in...
                  </>
                ) : (
                  'Sign In to Admin Portal'
                )}
              </Button>

              <div className="text-center text-xs text-muted-foreground">
                <p className="mb-2">Demo Credentials:</p>
                <p>
                  Email: <span className="font-mono font-bold">admin@hospital.com</span>
                </p>
                <p>
                  Password: <span className="font-mono font-bold">admin123</span>
                </p>
              </div>
            </form>
          )}

          {/* Success Step */}
          {step === 'success' && (
            <div className="text-center py-8 space-y-4">
              <div className="flex justify-center">
                <div className="rounded-full bg-health-green/20 p-4 animate-fade-in">
                  <CheckCircle className="w-12 h-12 text-health-green" />
                </div>
              </div>
              <div>
                <h2 className="text-2xl font-bold text-foreground mb-2">
                  Login Successful
                </h2>
                <p className="text-muted-foreground text-sm">
                  Welcome to Admin Portal
                </p>
              </div>
              <p className="text-xs text-muted-foreground">
                Redirecting to admin dashboard...
              </p>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="text-center mt-6 text-slate-200 text-xs">
          <p>Hospital Management System</p>
          <p className="mt-2">Powered by ABDM - Ayushman Bharat Digital Mission</p>
        </div>
      </div>
    </div>
  );
}
