import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import {
  Stethoscope,
  User,
  Building2,
  GraduationCap,
  ArrowRight,
} from 'lucide-react';

export default function RoleSelection() {
  const navigate = useNavigate();

  const roles = [
    {
      id: 'doctor',
      title: 'Doctor',
      description: 'Healthcare professional using ABHA ID for diagnosis coding and patient management',
      icon: Stethoscope,
      color: 'bg-health-teal',
      path: '/login/doctor',
      features: [
        'Diagnosis search & mapping',
        'Patient record management',
        'ABHA ID authentication',
        'Encounter documentation',
      ],
    },
    {
      id: 'patient',
      title: 'Patient',
      description: 'Access your medical records and health information',
      icon: User,
      color: 'bg-health-blue',
      path: '/login/patient',
      features: [
        'View medical records',
        'Appointment history',
        'Health information',
        'Consultation history',
      ],
    },
    {
      id: 'admin',
      title: 'Hospital Admin',
      description: 'Manage hospital operations and clinical workflows',
      icon: Building2,
      color: 'bg-health-green',
      path: '/login/admin',
      features: [
        'Hospital management',
        'Doctor & staff management',
        'Patient records overview',
        'System analytics',
      ],
    },
    {
      id: 'dean',
      title: 'Dean / Institution Head',
      description: 'Institutional oversight and policy management',
      icon: GraduationCap,
      color: 'bg-amber-600',
      path: '/login/dean',
      features: [
        'Institution management',
        'Policy oversight',
        'Report generation',
        'System administration',
      ],
    },
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted dark:from-slate-900 dark:to-slate-800">
      {/* Header */}
      <div className="border-b border-border dark:border-slate-700 bg-card dark:bg-slate-800/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center gap-3">
          <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-health-blue to-health-teal flex items-center justify-center shadow-md">
            <span className="text-white font-bold text-sm">DB</span>
          </div>
          <div>
            <h1 className="text-lg font-bold text-foreground">DiagnoBridge</h1>
            <p className="text-xs text-muted-foreground">Interop</p>
          </div>
        </div>
      </div>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        {/* Page Title */}
        <div className="text-center mb-16">
          <h2 className="text-4xl lg:text-5xl font-bold text-foreground mb-4">
            Select Your Role
          </h2>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Choose your user role to access the AYUSH-ICD11 system with appropriate
            permissions and features
          </p>
        </div>

        {/* Role Cards Grid */}
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
          {roles.map((role) => {
            const IconComponent = role.icon;
            return (
              <Card
                key={role.id}
                className="flex flex-col cursor-pointer hover:shadow-lg transition-all duration-300 hover:-translate-y-1 border-border dark:border-slate-700"
              >
                <CardHeader>
                  <div className={`w-12 h-12 rounded-lg ${role.color} flex items-center justify-center mb-4 text-white`}>
                    <IconComponent className="w-6 h-6" />
                  </div>
                  <CardTitle>{role.title}</CardTitle>
                  <CardDescription className="text-xs">
                    {role.description}
                  </CardDescription>
                </CardHeader>

                <CardContent className="flex-grow space-y-6">
                  {/* Features List */}
                  <div className="space-y-2">
                    {role.features.map((feature, idx) => (
                      <div key={idx} className="flex items-start gap-2 text-sm">
                        <div className="w-1.5 h-1.5 rounded-full bg-foreground/40 mt-1.5 flex-shrink-0"></div>
                        <span className="text-muted-foreground">{feature}</span>
                      </div>
                    ))}
                  </div>

                  {/* Login Button */}
                  <Button
                    onClick={() => navigate(role.path)}
                    className="w-full btn-primary mt-auto"
                  >
                    Login as {role.title}
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Demo Credentials Info */}
        <Card className="mt-16 bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
          <CardHeader>
            <CardTitle className="text-lg">Demo Credentials</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-4 text-sm">
              <div>
                <p className="font-semibold text-foreground mb-1">Doctor</p>
                <p className="text-muted-foreground">ABHA ID: 123456789012</p>
                <p className="text-muted-foreground">OTP: 123456</p>
              </div>
              <div>
                <p className="font-semibold text-foreground mb-1">Patient</p>
                <p className="text-muted-foreground">Email: patient@demo.com</p>
                <p className="text-muted-foreground">Password: password123</p>
              </div>
              <div>
                <p className="font-semibold text-foreground mb-1">Hospital Admin</p>
                <p className="text-muted-foreground">Email: admin@hospital.com</p>
                <p className="text-muted-foreground">Password: admin123</p>
              </div>
              <div>
                <p className="font-semibold text-foreground mb-1">Dean</p>
                <p className="text-muted-foreground">Email: dean@institution.com</p>
                <p className="text-muted-foreground">Password: dean123</p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Footer Link */}
        <div className="text-center mt-12">
          <Button
            onClick={() => navigate('/')}
            variant="ghost"
            className="text-muted-foreground hover:text-foreground"
          >
            ← Back to Home
          </Button>
        </div>
      </main>
    </div>
  );
}
