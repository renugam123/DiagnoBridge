export interface DiagnosisMapping {
  id: string;
  inputTerm: string;
  inputSystem: string;
  namaste: {
    code: string;
    name: string;
  };
  icd11tm2: {
    code: string;
    name: string;
    confidence: number;
  };
  icd11biomedical: {
    code: string;
    name: string;
    confidence: number;
  };
  description: string;
  whoDetails: {
    definition: string;
    symptoms: string[];
    riskFactors: string[];
    prevention: string[];
    treatment: string[];
  };
  synonyms: string[];
}

export const diagnosisMappings: DiagnosisMapping[] = [
  {
    id: '1',
    inputTerm: 'Jvara',
    inputSystem: 'Ayurveda',
    namaste: {
      code: 'NAMA-001',
      name: 'Jvara (Fever)',
    },
    icd11tm2: {
      code: 'BA4G.Y',
      name: 'Fever of undefined origin',
      confidence: 0.92,
    },
    icd11biomedical: {
      code: 'BA47',
      name: 'Fever, unspecified',
      confidence: 0.88,
    },
    description: 'Fever is characterized by elevated body temperature, general malaise, and disturbance of bodily functions. In Ayurveda, Jvara is classified into various types based on the predominant dosha involved.',
    whoDetails: {
      definition: 'Fever is an abnormal elevation of body temperature above the normal range (37°C or 98.6°F), typically in response to infection or illness.',
      symptoms: ['Body temperature above 38°C (100.4°F)', 'Chills and sweating', 'General malaise and weakness', 'Headache', 'Muscle aches', 'Reduced appetite'],
      riskFactors: ['Bacterial infections', 'Viral infections', 'Inflammatory conditions', 'Immunocompromised state', 'Environmental factors'],
      prevention: ['Maintain proper hygiene', 'Vaccinations as recommended', 'Avoid contact with infected individuals', 'Proper nutrition and hydration', 'Regular health check-ups'],
      treatment: ['Antipyretic medications (Paracetamol, Ibuprofen)', 'Adequate fluid intake', 'Rest and bed rest', 'Cool compresses', 'Treatment of underlying cause'],
    },
    synonyms: ['Tapa', 'Ushnatara', 'Fever', 'Pyrexia', 'Temperature'],
  },
  {
    id: '2',
    inputTerm: 'Diabetes Mellitus',
    inputSystem: 'Modern Biomedicine',
    namaste: {
      code: 'NAMA-002',
      name: 'Madhumeha',
    },
    icd11tm2: {
      code: 'BA7P',
      name: 'Diabetes mellitus',
      confidence: 0.95,
    },
    icd11biomedical: {
      code: 'BA7P.5',
      name: 'Type 2 diabetes mellitus',
      confidence: 0.89,
    },
    description: 'A metabolic disease characterized by elevated blood glucose levels. In Ayurveda, known as Madhumeha, it is primarily associated with Kapha dosha imbalance and affects the tissue layer of Rasa and Meda.',
    whoDetails: {
      definition: 'Diabetes mellitus is a chronic disease that occurs when the pancreas cannot produce enough insulin or when the body cannot effectively use the insulin it produces.',
      symptoms: ['Increased thirst', 'Frequent urination', 'Unexplained weight loss', 'Extreme fatigue', 'Blurred vision', 'Slow-healing wounds'],
      riskFactors: ['Family history of diabetes', 'Obesity', 'Sedentary lifestyle', 'Age above 45 years', 'High blood pressure', 'Poor diet'],
      prevention: ['Maintain healthy weight', 'Regular physical activity (150 min/week)', 'Healthy diet rich in fiber', 'Limit sugar and processed foods', 'Regular health screening'],
      treatment: ['Oral medications (Metformin, Sulfonylureas)', 'Insulin therapy', 'Dietary modifications', 'Exercise program', 'Blood sugar monitoring'],
    },
    synonyms: ['Madhumeha', 'Blood Sugar Disorder', 'Glycemic Disorder', 'Hyperglycemia'],
  },
  {
    id: '3',
    inputTerm: 'Amavata',
    inputSystem: 'Ayurveda',
    namaste: {
      code: 'NAMA-003',
      name: 'Amavata (Rheumatoid Arthritis)',
    },
    icd11tm2: {
      code: 'BA61.Y',
      name: 'Rheumatoid arthritis',
      confidence: 0.91,
    },
    icd11biomedical: {
      code: 'BA61',
      name: 'Rheumatoid arthritis',
      confidence: 0.90,
    },
    description: 'An inflammatory condition affecting joints, characterized by pain, swelling, and restricted movement. Amavata in Ayurveda represents the accumulation of undigested metabolic waste (Ama) combined with Vata aggravation.',
    whoDetails: {
      definition: 'Rheumatoid arthritis is a chronic inflammatory disorder that primarily affects small joints but can involve other body systems.',
      symptoms: ['Joint pain and stiffness', 'Swelling in joints', 'Reduced joint mobility', 'Morning stiffness lasting hours', 'Fatigue', 'Low-grade fever'],
      riskFactors: ['Female gender', 'Family history', 'Smoking', 'Obesity', 'Hormonal factors', 'Environmental factors'],
      prevention: ['Maintain healthy weight', 'Avoid smoking', 'Limit alcohol consumption', 'Regular physical activity', 'Stress management'],
      treatment: ['DMARDs (Disease-modifying antirheumatic drugs)', 'Biologic agents', 'NSAIDs for pain relief', 'Corticosteroids', 'Physiotherapy', 'Joint protection techniques'],
    },
    synonyms: ['Rheumatoid Arthritis', 'RA', 'Joint Inflammation', 'Vatarakta'],
  },
  {
    id: '4',
    inputTerm: 'Sirashoola',
    inputSystem: 'Ayurveda',
    namaste: {
      code: 'NAMA-004',
      name: 'Sirashoola (Headache)',
    },
    icd11tm2: {
      code: 'BA01.Y',
      name: 'Headache of tension type',
      confidence: 0.85,
    },
    icd11biomedical: {
      code: 'BA01',
      name: 'Tension headache',
      confidence: 0.83,
    },
    description: 'A condition characterized by pain in the head region. Sirashoola can be caused by various factors including Vata imbalance, stress, or impaired circulation. It may manifest as tension headache or migraine depending on the underlying etiology.',
    whoDetails: {
      definition: 'Headache is pain located in the head above the level of the eyes or ears or at the back of the head. It can be a primary disorder or secondary to another condition.',
      symptoms: ['Head pain or pressure', 'Pain on one side or both sides', 'Pain at the back of the head', 'Visual disturbances', 'Nausea and vomiting', 'Sensitivity to light or sound'],
      riskFactors: ['Stress and anxiety', 'Poor posture', 'Sleep deprivation', 'Muscle tension', 'Dehydration', 'Hormonal changes'],
      prevention: ['Manage stress effectively', 'Maintain good posture', 'Regular sleep schedule', 'Stay hydrated', 'Avoid triggers', 'Regular exercise'],
      treatment: ['Analgesics (Paracetamol, Aspirin)', 'NSAIDs', 'Rest in quiet dark room', 'Heat or cold therapy', 'Muscle relaxants', 'Lifestyle modifications'],
    },
    synonyms: ['Headache', 'Cephalalgia', 'Migraine', 'Tension Headache'],
  },
  {
    id: '5',
    inputTerm: 'Atisara',
    inputSystem: 'Ayurveda',
    namaste: {
      code: 'NAMA-005',
      name: 'Atisara (Diarrhea)',
    },
    icd11tm2: {
      code: 'DA94.Y',
      name: 'Diarrhea of unclear etiology',
      confidence: 0.88,
    },
    icd11biomedical: {
      code: 'DA94',
      name: 'Diarrhea',
      confidence: 0.87,
    },
    description: 'Increased frequency of bowel movements with loose or watery stools. Atisara in Ayurveda is primarily related to Pitta and Vata imbalance and indicates poor digestion or absorption.',
    synonyms: ['Diarrhea', 'Loose Stools', 'Dysentery', 'Gastroenteritis'],
  },
  {
    id: '6',
    inputTerm: 'Tamaka Svasa',
    inputSystem: 'Ayurveda',
    namaste: {
      code: 'NAMA-006',
      name: 'Tamaka Svasa (Asthma)',
    },
    icd11tm2: {
      code: 'CA93.Y',
      name: 'Asthma',
      confidence: 0.93,
    },
    icd11biomedical: {
      code: 'CA93',
      name: 'Asthma, unspecified',
      confidence: 0.92,
    },
    description: 'A chronic respiratory condition characterized by reversible airflow obstruction, bronchial hyperresponsiveness, and inflammation. Tamaka Svasa represents asthma with Vata-Kapha predominance in Ayurveda.',
    synonyms: ['Asthma', 'Bronchial Asthma', 'Breathing Difficulty', 'Dyspnea'],
  },
  {
    id: '7',
    inputTerm: 'Hypertension',
    inputSystem: 'Modern Biomedicine',
    namaste: {
      code: 'NAMA-007',
      name: 'Rakta Gata Vata',
    },
    icd11tm2: {
      code: 'BA84.Y',
      name: 'Essential hypertension',
      confidence: 0.90,
    },
    icd11biomedical: {
      code: 'BA84',
      name: 'Essential hypertension',
      confidence: 0.92,
    },
    description: 'A condition of persistently elevated blood pressure. In Ayurveda, it is associated with Rakta Gata Vata where Vata dosha becomes vitiated in the blood tissue, causing increased circulation and pressure.',
    synonyms: ['High Blood Pressure', 'Rakta Gata Vata', 'BP', 'Elevated Pressure'],
  },
  {
    id: '8',
    inputTerm: 'Eczema',
    inputSystem: 'Modern Biomedicine',
    namaste: {
      code: 'NAMA-008',
      name: 'Kushtha (Skin Disease)',
    },
    icd11tm2: {
      code: 'EF0C.Y',
      name: 'Atopic dermatitis',
      confidence: 0.87,
    },
    icd11biomedical: {
      code: 'EF0C',
      name: 'Atopic dermatitis',
      confidence: 0.89,
    },
    description: 'A chronic inflammatory skin condition causing itching, redness, and dryness. In Ayurveda, skin diseases are classified as Kushtha and are primarily related to Pitta and Kapha dosha imbalance.',
    synonyms: ['Dermatitis', 'Skin Rash', 'Itching', 'Atopic Eczema'],
  },
  {
    id: '9',
    inputTerm: 'Constipation',
    inputSystem: 'Modern Biomedicine',
    namaste: {
      code: 'NAMA-009',
      name: 'Vibandha',
    },
    icd11tm2: {
      code: 'DA91.Y',
      name: 'Constipation',
      confidence: 0.93,
    },
    icd11biomedical: {
      code: 'DA91',
      name: 'Constipation, unspecified',
      confidence: 0.94,
    },
    description: 'Reduced bowel movement frequency with difficulty in defecation. Vibandha in Ayurveda is primarily a Vata disorder characterized by increased dryness and reduced moisture in the colon.',
    synonyms: ['Constipation', 'Vibandha', 'Infrequent Stools', 'Hard Stools'],
  },
  {
    id: '10',
    inputTerm: 'Arthritis',
    inputSystem: 'Modern Biomedicine',
    namaste: {
      code: 'NAMA-010',
      name: 'Sandhivata',
    },
    icd11tm2: {
      code: 'BA86.Y',
      name: 'Osteoarthritis',
      confidence: 0.88,
    },
    icd11biomedical: {
      code: 'BA86',
      name: 'Osteoarthritis',
      confidence: 0.89,
    },
    description: 'Degenerative joint disease with cartilage breakdown. Sandhivata in Ayurveda results from Vata aggravation and reduced lubrication of the joints, leading to pain and stiffness.',
    synonyms: ['Osteoarthritis', 'Sandhivata', 'Joint Pain', 'Wear and Tear'],
  },
  {
    id: '11',
    inputTerm: 'Insomnia',
    inputSystem: 'Modern Biomedicine',
    namaste: {
      code: 'NAMA-011',
      name: 'Nidranasha',
    },
    icd11tm2: {
      code: 'CA40.Y',
      name: 'Insomnia, unspecified',
      confidence: 0.91,
    },
    icd11biomedical: {
      code: 'CA40',
      name: 'Insomnia',
      confidence: 0.93,
    },
    description: 'Chronic difficulty in falling or maintaining sleep. Nidranasha in Ayurveda is caused by Vata and Pitta aggravation, leading to mental restlessness and overactivity of the nervous system.',
    synonyms: ['Sleep Disorder', 'Sleeplessness', 'Nidranasha', 'Sleep Disturbance'],
  },
  {
    id: '12',
    inputTerm: 'Anxiety',
    inputSystem: 'Modern Biomedicine',
    namaste: {
      code: 'NAMA-012',
      name: 'Bhaya',
    },
    icd11tm2: {
      code: 'CA03.Y',
      name: 'Anxiety disorder',
      confidence: 0.86,
    },
    icd11biomedical: {
      code: 'CA03',
      name: 'Anxiety disorders',
      confidence: 0.84,
    },
    description: 'Persistent worry and nervousness affecting daily activities. Bhaya in Ayurveda represents fear and anxiety stemming from Vata imbalance, affecting the nervous system function.',
    synonyms: ['Anxiety Disorder', 'Fear', 'Nervousness', 'Worry'],
  },
  {
    id: '13',
    inputTerm: 'Kasa',
    inputSystem: 'Ayurveda',
    namaste: {
      code: 'NAMA-013',
      name: 'Kasa (Cough)',
    },
    icd11tm2: {
      code: 'CA2D.Y',
      name: 'Cough, unspecified',
      confidence: 0.89,
    },
    icd11biomedical: {
      code: 'CA2D',
      name: 'Cough',
      confidence: 0.91,
    },
    description: 'Reflex action of the respiratory system characterized by forced expulsion of air. Kasa in Ayurveda is classified based on dosha involvement, with Kapha cough being most common.',
    synonyms: ['Cough', 'Persistent Cough', 'Dry Cough', 'Productive Cough'],
  },
  {
    id: '14',
    inputTerm: 'Grahani',
    inputSystem: 'Ayurveda',
    namaste: {
      code: 'NAMA-014',
      name: 'Grahani (IBS-like Condition)',
    },
    icd11tm2: {
      code: 'DA95.Y',
      name: 'Irritable bowel syndrome',
      confidence: 0.82,
    },
    icd11biomedical: {
      code: 'DA95',
      name: 'Irritable bowel syndrome',
      confidence: 0.80,
    },
    description: 'A digestive disorder affecting the small intestine with alternating diarrhea and constipation. Grahani in Ayurveda indicates weak digestive fire and disturbed functions of nutrient absorption.',
    synonyms: ['IBS', 'Grahani', 'Weak Digestion', 'Malabsorption'],
  },
  {
    id: '15',
    inputTerm: 'Migraine',
    inputSystem: 'Modern Biomedicine',
    namaste: {
      code: 'NAMA-015',
      name: 'Ardhavabhedaka',
    },
    icd11tm2: {
      code: 'BA02.Y',
      name: 'Migraine with aura',
      confidence: 0.87,
    },
    icd11biomedical: {
      code: 'BA02',
      name: 'Migraine',
      confidence: 0.89,
    },
    description: 'Recurrent throbbing headache, typically unilateral. Ardhavabhedaka in Ayurveda is primarily a Pitta disorder causing burning sensation and sharp pain in half of the head.',
    synonyms: ['Migraine', 'Ardhavabhedaka', 'Hemicranial Pain', 'Throbbing Headache'],
  },
  {
    id: '16',
    inputTerm: 'Obesity',
    inputSystem: 'Modern Biomedicine',
    namaste: {
      code: 'NAMA-016',
      name: 'Medatva',
    },
    icd11tm2: {
      code: 'BA09.Y',
      name: 'Overweight and obesity',
      confidence: 0.91,
    },
    icd11biomedical: {
      code: 'BA09',
      name: 'Obesity',
      confidence: 0.93,
    },
    description: 'Abnormal or excessive fat accumulation in the body. Medatva in Ayurveda is primarily a Kapha disorder characterized by increased fat tissue and reduced metabolic activity.',
    synonyms: ['Obesity', 'Medatva', 'Overweight', 'Excessive Fat'],
  },
  {
    id: '17',
    inputTerm: 'Urticaria',
    inputSystem: 'Modern Biomedicine',
    namaste: {
      code: 'NAMA-017',
      name: 'Kotha',
    },
    icd11tm2: {
      code: 'EE84.Y',
      name: 'Urticaria',
      confidence: 0.90,
    },
    icd11biomedical: {
      code: 'EE84',
      name: 'Urticaria',
      confidence: 0.92,
    },
    description: 'Allergic skin reaction causing itchy hives and welts. Kotha in Ayurveda is a Pitta disorder involving allergic reactions and skin manifestations due to compromised immunity.',
    synonyms: ['Hives', 'Urticaria', 'Skin Allergy', 'Wheals'],
  },
  {
    id: '18',
    inputTerm: 'Pandu',
    inputSystem: 'Ayurveda',
    namaste: {
      code: 'NAMA-018',
      name: 'Pandu (Anemia)',
    },
    icd11tm2: {
      code: 'BA20.Y',
      name: 'Anemia of unspecified cause',
      confidence: 0.88,
    },
    icd11biomedical: {
      code: 'BA20',
      name: 'Anemia, unspecified',
      confidence: 0.87,
    },
    description: 'Deficiency in red blood cells or hemoglobin. Pandu in Ayurveda results from impaired digestion and reduced formation of blood tissue, causing paleness and weakness.',
    synonyms: ['Anemia', 'Pandu', 'Pallor', 'Blood Deficiency'],
  },
  {
    id: '19',
    inputTerm: 'Hypokalemia',
    inputSystem: 'Modern Biomedicine',
    namaste: {
      code: 'NAMA-019',
      name: 'Kshetaja Vikara',
    },
    icd11tm2: {
      code: 'BA06.Y',
      name: 'Electrolyte imbalance',
      confidence: 0.85,
    },
    icd11biomedical: {
      code: 'BA06',
      name: 'Dehydration and hypovolemia',
      confidence: 0.79,
    },
    description: 'Low levels of potassium in the blood affecting muscle and nerve function. In Ayurveda, this represents an imbalance of body elements (Kshetaja) leading to functional disorders.',
    synonyms: ['Low Potassium', 'Electrolyte Imbalance', 'Mineral Deficiency'],
  },
  {
    id: '20',
    inputTerm: 'Depression',
    inputSystem: 'Modern Biomedicine',
    namaste: {
      code: 'NAMA-020',
      name: 'Vishada',
    },
    icd11tm2: {
      code: 'CA41.Y',
      name: 'Depressive disorder',
      confidence: 0.89,
    },
    icd11biomedical: {
      code: 'CA41',
      name: 'Depressive disorders',
      confidence: 0.88,
    },
    description: 'Mental disorder characterized by persistent sadness and loss of interest. Vishada in Ayurveda represents a psychological state caused by Vata and Kapha imbalance affecting mind and emotions.',
    synonyms: ['Depression', 'Sadness', 'Melancholy', 'Mental Disorder'],
  },
  {
    id: '21',
    inputTerm: 'Psoriasis',
    inputSystem: 'Modern Biomedicine',
    namaste: {
      code: 'NAMA-021',
      name: 'Siddhakushtha',
    },
    icd11tm2: {
      code: 'EE21.Y',
      name: 'Psoriasis',
      confidence: 0.91,
    },
    icd11biomedical: {
      code: 'EE21',
      name: 'Psoriasis',
      confidence: 0.93,
    },
    description: 'Chronic inflammatory skin disease with red, scaly patches. Siddhakushtha in Ayurveda is a deeply rooted skin condition due to Vata and Pitta aggravation affecting all skin layers.',
    synonyms: ['Psoriasis', 'Chronic Dermatitis', 'Scaly Skin', 'Hereditary Skin Disease'],
  },
  {
    id: '22',
    inputTerm: 'Bronchitis',
    inputSystem: 'Modern Biomedicine',
    namaste: {
      code: 'NAMA-022',
      name: 'Kasa Roga',
    },
    icd11tm2: {
      code: 'CA25.Y',
      name: 'Bronchitis',
      confidence: 0.92,
    },
    icd11biomedical: {
      code: 'CA25',
      name: 'Bronchitis, unspecified',
      confidence: 0.90,
    },
    description: 'Inflammation of the bronchial tubes producing cough and sputum. Kasa Roga in Ayurveda particularly refers to respiratory diseases caused by Kapha and Vata dosha aggravation.',
    synonyms: ['Bronchitis', 'Bronchial Inflammation', 'Chest Infection'],
  },
  {
    id: '23',
    inputTerm: 'Thyroiditis',
    inputSystem: 'Modern Biomedicine',
    namaste: {
      code: 'NAMA-023',
      name: 'Kantha Roga',
    },
    icd11tm2: {
      code: 'BA50.Y',
      name: 'Thyroiditis',
      confidence: 0.86,
    },
    icd11biomedical: {
      code: 'BA50',
      name: 'Thyroiditis',
      confidence: 0.88,
    },
    description: 'Inflammation of the thyroid gland affecting hormone production. Kantha Roga in Ayurveda refers to throat disorders including thyroid dysfunction due to Pitta aggravation.',
    synonyms: ['Thyroid Disease', 'Thyroiditis', 'Goiter', 'Thyroid Inflammation'],
  },
  {
    id: '24',
    inputTerm: 'Vitiligo',
    inputSystem: 'Modern Biomedicine',
    namaste: {
      code: 'NAMA-024',
      name: 'Shvitra',
    },
    icd11tm2: {
      code: 'EE09.Y',
      name: 'Vitiligo',
      confidence: 0.90,
    },
    icd11biomedical: {
      code: 'EE09',
      name: 'Vitiligo',
      confidence: 0.92,
    },
    description: 'Loss of skin pigmentation in patches. Shvitra in Ayurveda is a Pitta disorder caused by impaired digestion leading to accumulation of toxins affecting skin pigmentation.',
    synonyms: ['Vitiligo', 'Depigmentation', 'White Patches', 'Loss of Color'],
  },
  {
    id: '25',
    inputTerm: 'Urinary Tract Infection',
    inputSystem: 'Modern Biomedicine',
    namaste: {
      code: 'NAMA-025',
      name: 'Mootraghata',
    },
    icd11tm2: {
      code: 'BA87.Y',
      name: 'Urinary tract infection',
      confidence: 0.89,
    },
    icd11biomedical: {
      code: 'BA87',
      name: 'Urinary tract infection',
      confidence: 0.91,
    },
    description: 'Bacterial infection in the urinary system. Mootraghata in Ayurveda refers to obstruction and dysuria caused by Vata and Pitta imbalance affecting the urinary channels.',
    synonyms: ['UTI', 'Bladder Infection', 'Dysuria', 'Urinary Infection'],
  },
  {
    id: '26',
    inputTerm: 'Cervical Spondylitis',
    inputSystem: 'Modern Biomedicine',
    namaste: {
      code: 'NAMA-026',
      name: 'Greeva Stambha',
    },
    icd11tm2: {
      code: 'BA47.Y',
      name: 'Cervical spondylosis',
      confidence: 0.88,
    },
    icd11biomedical: {
      code: 'BA47',
      name: 'Spondylosis',
      confidence: 0.86,
    },
    description: 'Degenerative changes in cervical spine causing pain and stiffness. Greeva Stambha in Ayurveda results from Vata aggravation causing spinal degeneration and nerve compression.',
    synonyms: ['Cervical Spondylitis', 'Neck Pain', 'Cervical Arthritis', 'Neck Stiffness'],
  },
  {
    id: '27',
    inputTerm: 'Gastritis',
    inputSystem: 'Modern Biomedicine',
    namaste: {
      code: 'NAMA-027',
      name: 'Amlapitta',
    },
    icd11tm2: {
      code: 'DA10.Y',
      name: 'Gastritis',
      confidence: 0.91,
    },
    icd11biomedical: {
      code: 'DA10',
      name: 'Gastritis',
      confidence: 0.92,
    },
    description: 'Inflammation of the stomach lining causing pain and discomfort. Amlapitta in Ayurveda is a Pitta disorder with excessive stomach acid causing burning sensation and acidity.',
    synonyms: ['Gastritis', 'Acidity', 'Stomach Inflammation', 'GERD'],
  },
  {
    id: '28',
    inputTerm: 'Measles',
    inputSystem: 'Modern Biomedicine',
    namaste: {
      code: 'NAMA-028',
      name: 'Masurika',
    },
    icd11tm2: {
      code: 'BA0E.Y',
      name: 'Measles',
      confidence: 0.94,
    },
    icd11biomedical: {
      code: 'BA0E',
      name: 'Measles',
      confidence: 0.95,
    },
    description: 'Viral infection characterized by fever and distinctive rash. Masurika in Ayurveda is a well-recognized infectious disease with Pitta and Kapha involvement causing systemic symptoms.',
    synonyms: ['Measles', 'Rubeola', 'Viral Rash', 'Infectious Disease'],
  },
  {
    id: '29',
    inputTerm: 'Varicose Veins',
    inputSystem: 'Modern Biomedicine',
    namaste: {
      code: 'NAMA-029',
      name: 'Siraja Roga',
    },
    icd11tm2: {
      code: 'BB70.Y',
      name: 'Varicose veins',
      confidence: 0.89,
    },
    icd11biomedical: {
      code: 'BB70',
      name: 'Varicose veins',
      confidence: 0.91,
    },
    description: 'Enlarged and tortuous veins causing venous insufficiency. Siraja Roga in Ayurveda involves deranged Vata affecting blood vessels and causing vein enlargement and blood stagnation.',
    synonyms: ['Varicose Veins', 'Venous Disease', 'Vein Enlargement', 'Phlebitis'],
  },
  {
    id: '30',
    inputTerm: 'Leucoderma',
    inputSystem: 'Modern Biomedicine',
    namaste: {
      code: 'NAMA-030',
      name: 'Shvitra',
    },
    icd11tm2: {
      code: 'EE09.Y',
      name: 'Leucoderma / Vitiligo',
      confidence: 0.90,
    },
    icd11biomedical: {
      code: 'EE09',
      name: 'Depigmentation disorder',
      confidence: 0.89,
    },
    description: 'Loss of skin color in patches due to melanin deficiency. Leucoderma in modern medicine and Shvitra in Ayurveda both involve depigmentation caused by autoimmune factors and constitutional imbalance.',
    synonyms: ['Leucoderma', 'Vitiligo', 'White Patches', 'Skin Depigmentation'],
  },
];

export const medicalSystems = [
  'Ayurveda',
  'Siddha',
  'Unani',
  'Homeopathy',
  'Modern Biomedicine',
];

export const searchDiagnosis = (term: string): DiagnosisMapping | undefined => {
  const lowerTerm = term.toLowerCase();
  return diagnosisMappings.find(
    (mapping) =>
      mapping.inputTerm.toLowerCase().includes(lowerTerm) ||
      mapping.namaste.name.toLowerCase().includes(lowerTerm) ||
      mapping.synonyms.some((syn) => syn.toLowerCase().includes(lowerTerm))
  );
};

export const validateAbhaId = (abhaId: string): boolean => {
  // ABHA ID validation: 12 digits or XXXX-XXXX-XXXX format
  const abhaPattern = /^(\d{12}|\d{4}-\d{4}-\d{4})$/;
  return abhaPattern.test(abhaId);
};

export const validateOtp = (otp: string): boolean => {
  // OTP validation: 6 digits
  return /^\d{6}$/.test(otp);
};

export const validateEmail = (email: string): boolean => {
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailPattern.test(email);
};
